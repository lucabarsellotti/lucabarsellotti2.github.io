from tensorflow.keras.applications.inception_v3 import InceptionV3

#PATHS
BASE_DIR = 'resources/'
ART_DATASET = BASE_DIR + "Art Images/dataset_updated/"
TRAINING_SET = ART_DATASET + "training_set/"
VALIDATION_SET = ART_DATASET + "validation_set/"
DISTRACTOR_SET = BASE_DIR + "mirflickr/"
QUERY_SET = "query/"

#NETWORK
BATCH_SIZE = 32
IMAGE_SIZE = (229,229)
IMAGE_SHAPE = (229,229,3)
PRETRAINED_MODEL = InceptionV3(include_top=False, weights='imagenet', input_shape=IMAGE_SHAPE)
EPOCHS_NUMBER = 10
LEARNING_RATE = 0.0001
OPTIMIZER = "Adam"
# OPTIMIZER=tf.keras.optimizers.SGD(learning_rate=0.01, momentum=0.0, nesterov=False, name="SGD")
# OPTIMIZER=tf.keras.optimizers.Adadelta(learning_rate=0.001, rho=0.95, epsilon=1e-07, name="Adadelta")
LOSS_FUNCTION = "sparse_categorical_crossentropy"
METRIC = "accuracy"

#INDEX
MAX_LEVEL = 5
BUCKET_SIZE = 307
FEATURES_FINE_TUNED_FILENAME = 'resources/feature_extracted_fine_tuned'
FEATURES_NOT_FINE_TUNED_FILENAME = 'resources/features_extracted_not_fine_tuned'

#QUERY
RANGE = 0.5
K = 10

VALIDATION_LENGTH = 856
TRAINING_LENGTH = 7721
