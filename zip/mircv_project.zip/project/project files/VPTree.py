import heapq
import math

import random
import numpy as np
from FeaturesSchema import FeaturesSchema

class PriorityQueue:
  def __init__(self,k):
    self.data = []
    self.index = 0
    self.size = k

  def push(self, priority, item):
    heapq.heappush(self.data,(-priority,self.index,item))
    self.index += 1

  def is_full(self):
    return len(self.data) == self.size

  def pop(self):
    return heapq.heappop(self.data)


class Node:
    def __init__(self):
        self.leaf = False

    def add_left(self, node):
        self.left = node

    def add_right(self, node):
        self.right = node

    def set_median(self, median):
        self.median = median

    def set_pivot(self, pivot):
        self.pivot = pivot

    def get_median(self):
        return self.median

    def get_pivot(self):
        return self.pivot

    def get_left(self):
        return self.left

    def get_right(self):
        return self.right

    def set_leaf(self, subset):
        self.subset = subset
        self.leaf = True

    def get_subset(self):
        return self.subset

    def is_leaf(self):
        return self.leaf


class VPTree:

    # Recursive function used to build the tree
    def build(self, node, feature_subset, leaf=False):

        if leaf is True:
            # if the node is a leaf we have to enter the features schemas in its bucket
            node.set_leaf(feature_subset)
        else:
            # if the node is an internal node, we randomly choose the pivot
            pivot = random.choice(feature_subset)
            # then we evaluate the distances between the pivot and all the other objects
            distances = list()
            for feature_schema in feature_subset:
                distances.append(feature_schema.distance_from(pivot))
            distances = np.array(distances)
            # evaluate the median distance
            median = np.median(distances)
            subset1 = list()
            subset2 = list()
            for feature_schema in feature_subset:
                # if the distance is lower than the media, the feature_schema will go in the left subset (subset1)
                if feature_schema.distance_from(pivot) <= median:
                    subset1.append(feature_schema)
                else:
                    # otherwise it will go in the right subset
                    subset2.append(feature_schema)
            # setting the values for the pivot node
            node.set_median(median)
            node.set_pivot(pivot)
            # add left and right sons, increment the number of nodes
            node.add_left(Node())
            node.add_right(Node())
            self.nodes += 2
            # if the length of the left subset is lower than the bucket size, then we can directly build the leaf node
            if len(subset1) <= self.bucket_size:
                self.build(node.get_left(), subset1, leaf=True)
            else:
                # otherwise we have to do all the above procedure for another pivot, splitting the data again...
                self.build(node.get_left(), subset1)
            # same for right subset
            if len(subset2) <= self.bucket_size:
                self.build(node.get_right(), subset2, leaf=True)
            else:
                self.build(node.get_right(), subset2)

    def __init__(self, feature_schemas, bucket_size):
        self.bucket_size = bucket_size
        self.feature_schemas = feature_schemas
        self.nodes = 1
        self.root = Node()
        self.build(self.root, feature_schemas)

    # function to print the tree, it will call print_tree
    def print_root(self):
        self.print_tree(self.root)

    # recursive function to print the tree
    def print_tree(self, node):
        if node.is_leaf():
            print("LEAF")
            print(len(node.subset))
            return
        else:
            print("INTERNAL")
            print("Pivot: ", node.get_pivot().tensor)
            print("Median: ", node.get_median())
            self.print_tree(node.get_left())
            self.print_tree(node.get_right())
            return

    # function to perform the range search for a given query and a certain range
    def range_search(self, query, range):
        self.range_search_return_list = list()
        self.recursive_range_search(self.root, query, range)
        return self.range_search_return_list

    # recursive function to perform the range search
    def recursive_range_search(self, node, query, range):
        if node.is_leaf() == True:
            # if the node is a leaf, then we have to search in its bucket for objects
            # that have a smaller distance than the range. These objects will be
            # inserted in the result
            for object_schema in node.get_subset():
                if query.distance_from(object_schema) <= range:
                    tmp = []
                    tmp.append(object_schema)
                    tmp.append(query.distance_from(object_schema))
                    self.range_search_return_list.append(tmp)
            return
        # if the distance between the query and the pivot is smaller than the
        # range, we insert the pivot in the result
        if query.distance_from(node.get_pivot()) <= range:
            tmp = []
            tmp.append(node.get_pivot())
            tmp.append(query.distance_from(node.get_pivot()))
            self.range_search_return_list.append(tmp)

        # if the distance between the query and the pivot minus the range is smaller
        # than the median, we have to search in the left son of the pivot
        if query.distance_from(node.get_pivot()) - range <= node.get_median():
            self.recursive_range_search(node.get_left(), query, range)
        # otherwise we have to search in the right son
        if query.distance_from(node.get_pivot()) + range >= node.get_median():
            self.recursive_range_search(node.get_right(), query, range)
        return

    # function to perform the knn search for a given query a certain k
    def knn(self, query, k):
        # contains the maximum distance between the query and the neighbors
        # in the result
        self.d_max = math.inf
        # priority queue to save the results of the knn
        self.nn = PriorityQueue(k)
        # perform the knn search on the tree
        self.recursive_knn(self.root, query, k)
        results = list()
        # once the knn is finished, we extract the results from
        # the priority queue and we return them
        while k != 0:
            tmp = self.nn.pop()
            results.append((abs(tmp[0]), tmp[2]))
            k -= 1
        return list(reversed(results))

    # recursive function to perform the knn search
    def recursive_knn(self, node, query, k):
        if node.is_leaf() == True:
            # if the node is a leaf, it's the same reasoning applied to a pivot,
            # with the exception that we have to repeat this reasoning for all
            # the objects in the leaf's bucket.
            for object_schema in node.get_subset():
                distance = query.distance_from(object_schema)
                if not self.nn.is_full():
                    self.nn.push(priority=distance, item=object_schema)
                    self.d_max = distance if self.d_max < distance else self.d_max
                elif abs(distance) < abs(self.d_max):
                    self.nn.pop()
                    self.nn.push(priority=distance, item=object_schema)
                    tmp = self.nn.data[0][0]
                    self.d_max = abs(tmp)
            return
        # if the node is a pivot, we check the distance from the query and the pivot
        distance = query.distance_from(node.get_pivot())
        if not self.nn.is_full():
            # if the priority queue is not full, we insert the pivot in it and
            # check if the distance between the query and the pivot is greater than
            # the current d_max. If this is true, we update d_max to this distance.
            # Otherwise, d_max is not updated.
            self.nn.push(priority=distance, item=node.get_pivot())
            self.d_max = distance if self.d_max < distance else self.d_max
        elif abs(distance) < abs(self.d_max):
            # if the priority queue is full, we have to check if the distance
            # between the pivot and the query is lower than the d_max. If this
            # happens, we remove the object with the highest distance
            # and we insert the pivot in the priority queue. In addition, we
            # update d_max to the distance between the current pivot and the query
            self.nn.pop()
            self.nn.push(priority=distance, item=node.get_pivot())
            tmp = self.nn.data[0][0]
            self.d_max = abs(tmp)
        # if the distance between the pivot and the query minus the current max
        # distance is lower or equal than the median of the pivot, we have to search
        # in the left son.
        if distance - self.d_max <= node.get_median():
            self.recursive_knn(node.get_left(), query, k)
        # otherwise we search in the right son.
        if distance + self.d_max >= node.get_median():
            self.recursive_knn(node.get_right(), query, k)
        return

    # function that performs the knn search in a linear way, without using the
    # index. Used for performance comparisons.
    def knn_not_optimized(self, query, k):
        results = list()
        for object_schema in self.feature_schemas:
            distance = object_schema.distance_from(query)
            results.append((distance, object_schema))
        print(len(self.feature_schemas))
        return sorted(results, key=lambda x: x[0])