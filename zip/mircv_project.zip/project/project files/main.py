
from flask import Flask, render_template, request,jsonify, send_file,make_response
import base64
from PIL import Image
import io
from base64 import encodebytes
import pickle
from FeaturesSchema import FeaturesSchema
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
from tensorflow.keras.applications import *
from sklearn.preprocessing import normalize
from CONSTANTS import *
from utility import *
from DNNExtractor import DNNExtractor
from VPTree import VPTree
import numpy as np
import cv2
import timeit
from datetime import datetime


app = Flask(__name__)

@app.route('/')
def home():
   return render_template('home.html',name="Set your query")


def get_response_image(image_path):
   pil_img = Image.open(image_path, mode='r')  # reads the PIL image
   byte_arr = io.BytesIO()
   pil_img.save(byte_arr, format='PNG')  # convert the PIL image to byte array
   encoded_img = encodebytes(byte_arr.getvalue()).decode('ascii')  # encode as base64
   return encoded_img

@app.route('/handle_data', methods=['POST'])
def handle_data():
   print(request.form)
   print(request.form['search'])
   isThisFile = request.files.get('file')
   print(isThisFile)

   isThisFile.save(QUERY_SET +"query/"+ isThisFile.filename)

   query_feature_schema = dnn.extract_features_from_single_image(QUERY_SET + isThisFile.filename)
   start_time = datetime.now()
   # do your work here

   if request.form['search'] == "knn":
      results = vptree.knn(query_feature_schema, int(request.form['k']))
   if request.form['search'] == "range":
      results = vptree.range_search(query_feature_schema, int(request.form['k'])/100)

   end_time = datetime.now()
   print('Duration: {}'.format(end_time - start_time))
   time = str(end_time - start_time)
   #KNN QUERY
   # results = vptree.knn(query_feature_schema, int(request.form['k']))
   encoded_imges = []
   distances = []
   classes = []
   response = dict()
   response['time'] = time

   print("Result len: ", len(results))
   print("features extracted before:", vptree.feature_schemas[0].tensor)
   print("features extracted now", query_feature_schema.tensor[0])
   query_feature_schema.tensor = query_feature_schema.tensor[0]
   print("their distance is: ", vptree.feature_schemas[0].distance_from(query_feature_schema))

   if request.form['search'] == 'knn':
      for result in results:
         #print("Tensor: ", result[1].tensor)
         print("Distance: ", result[0])
         distances.append(str(result[0]))
         print("Image id: ", result[1].img_id.replace('\\', '/'))
         classes.append(result[1].label)
         try:
            encoded_imges.append(get_response_image(VALIDATION_SET +result[1].img_id.replace('\\', '/')))
         except:
            try:
               encoded_imges.append(get_response_image(TRAINING_SET + result[1].img_id.replace('\\', '/')))
            except:
               try:
                  encoded_imges.append(get_response_image(DISTRACTOR_SET + result[1].img_id.replace('\\', '/')))
               except:
                  pass

   if request.form['search'] == 'range':
      results = sorted(results, key = lambda x: x[1])
      for result in results:
         # print("Tensor: ", result[1].tensor)
         print("distance: ",result[1])
         print("Image id: ", result[0].img_id.replace('\\', '/'))
         classes.append(result[0].label)
         try:
            encoded_imges.append(get_response_image(VALIDATION_SET + result[0].img_id.replace('\\', '/')))
         except:
            try:
               encoded_imges.append(get_response_image(TRAINING_SET + result[0].img_id.replace('\\', '/')))
            except:
               try:
                  encoded_imges.append(get_response_image(DISTRACTOR_SET + result[0].img_id.replace('\\', '/')))
               except:
                  pass


   """"
   #RANGE QUERY
   RANGE = 0.4
   results = vptree.range_search(query_feature_schema, RANGE)
   tmp = sorted(results, lambda x: x[0])
   for result in results:
      
      print(result.tensor)
      print(result.img_id)
   #remove query file
   os.remove(QUERY_SET + isThisFile.filename)
   encoded_imges = []
   """
   os.remove(QUERY_SET +"query/"+ isThisFile.filename)
   response['encoded_images'] = encoded_imges
   response['distances'] = distances
   response['classes'] = classes
   return jsonify(response)


if __name__ == '__main__':
   print("Loading index....")
   vptree = read_index_from_file("index")
   print("Index loaded!")
   print("Loading model....")
   model = tf.keras.models.load_model(os.path.join(BASE_DIR, "fine_tuned_model"))
   dnn = DNNExtractor(model, BATCH_SIZE, False)
   print("Model loaded!")
   app.run(debug=False)

