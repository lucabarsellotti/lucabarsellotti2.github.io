from sklearn.preprocessing import normalize
import tensorflow as tf
import numpy as np
from tensorflow.keras.models import Model
from CONSTANTS import *
from tensorflow.keras.applications import *
from FeaturesSchema import FeaturesSchema
from tensorflow.python.keras.applications.inception_resnet_v2 import preprocess_input

class DNNExtractor:
    def __init__(self, model, batch_size, trainable):
        model.trainable = trainable
        self.net = model
        self.batch_size = batch_size
        self.trainable = trainable

    def extract_features(self, dataset, normalization=False, remove_classifier=False, layer_to_stop='gap'):
        if remove_classifier:
            # if remove_classifier is true, we remove the last layer.
            # remove_classifier = False when using pre-trained network
            self.net = Model(inputs=self.net.input, outputs=self.net.get_layer(layer_to_stop).output)
        dataset_extracted = self.net.predict(dataset, batch_size=self.batch_size)
        if normalization is True:
            dataset_extracted = normalize(dataset_extracted)
        return dataset_extracted

    def fine_tune(self, training_set, validation_set, optimizer, loss, metric, learning_rate, epochs, class_weight):
        if not self.trainable:
            print("Net not trainable")
            return

        if optimizer == "Adam":
            optimizer = tf.keras.optimizers.Adam(learning_rate)
        elif optimizer == "RMSprop":
            optimizer = tf.keras.optimizers.RMSprop(learning_rate)

        self.net.compile(optimizer=optimizer, loss=loss, metrics=[metric])

        self.net.fit(training_set, validation_data=validation_set, epochs=epochs,
                     steps_per_epoch=np.ceil(6179 / float(BATCH_SIZE)),
                     validation_steps=np.ceil(1542 / float(BATCH_SIZE)), class_weight=class_weight)

    def extract_features_from_single_image(self, filename, layer_to_stop="gap"):
        data_gen = tf.keras.preprocessing.image.ImageDataGenerator(preprocessing_function=preprocess_input)
        query_gen = data_gen.flow_from_directory(
            QUERY_SET,
            shuffle=False,
            target_size=IMAGE_SIZE,
            batch_size=BATCH_SIZE
        )
        query_features = self.extract_features(query_gen, True, True,layer_to_stop=layer_to_stop)
        query_feature_schema = FeaturesSchema(query_features, filename, "")
        return query_feature_schema

