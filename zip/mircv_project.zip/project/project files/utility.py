import glob
from keras.preprocessing import image
import os

from tensorflow.python.keras.models import Sequential
from tensorflow.keras import layers

from CONSTANTS import *
import tensorflow as tf
from tensorflow.keras.applications.inception_v3 import preprocess_input
from FeaturesSchema import FeaturesSchema
import pickle


def remove_corrupted_images():
    train_ids = glob.glob(TRAINING_SET + "/*/*.jpg")
    valid_ids = glob.glob(VALIDATION_SET + "/*/*.jpg")
    distractor_ids = glob.glob(DISTRACTOR_SET + "mirflickr/*.jpg")
    img_ids = train_ids + valid_ids + distractor_ids
    for img in img_ids:
         try:
             image.load_img(img, target_size=(150,150))
         except:
             print(img, "removed!")
             os.remove(img)
def get_datasets_for_pretrained_network():
    data_gen = tf.keras.preprocessing.image.ImageDataGenerator(preprocessing_function=preprocess_input)
    train_art_dataset = data_gen.flow_from_directory(
        TRAINING_SET,
        shuffle=False,
        target_size=(229, 229),
        batch_size=BATCH_SIZE)

    valid_art_dataset = data_gen.flow_from_directory(
        VALIDATION_SET,
        shuffle=False,
        target_size=(229, 229),
        batch_size=BATCH_SIZE)

    distractor_dataset = data_gen.flow_from_directory(
         DISTRACTOR_SET,
         shuffle=False,
         target_size=(229, 229),
         batch_size=BATCH_SIZE)
    return train_art_dataset, valid_art_dataset, distractor_dataset


def get_datasets_for_finetuned_network(shuffle=True):
    train_datagen = image.ImageDataGenerator(
        rescale=1. / 255,
        rotation_range=40,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=20,
        zoom_range=0.2,
        horizontal_flip=True)

    test_datagen = image.ImageDataGenerator(rescale=1. / 255)

    train_generator = train_datagen.flow_from_directory(
        TRAINING_SET,
        target_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='sparse',
        shuffle=shuffle)

    validation_generator = test_datagen.flow_from_directory(
        VALIDATION_SET,
        target_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='sparse',
        shuffle=shuffle)

    distractor_dataset = test_datagen.flow_from_directory(
        DISTRACTOR_SET,
        shuffle=shuffle,
        target_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE)

    return validation_generator, train_generator, distractor_dataset



def create_feature_schema(dnn, features_list, dataset, distractor=False, remove_classifier=False):
    features = dnn.extract_features(dataset, normalization=True, remove_classifier=remove_classifier)
    #print(dataset[0][1])
    for i in range(0,len(dataset.filenames)):

        #print(i)

        if distractor == True:
          label="Distractor"
        else:
          label = dataset.filenames[i].split("\\")[0]
        feature_schema = FeaturesSchema(tensor = features[i], img_id=dataset.filenames[i], label=label)
        #print(feature_schema.img_id, feature_schema.label)
        features_list.append(feature_schema)

def save_features_into_file(filename,feature_schemas):
    with open(BASE_DIR + filename, 'wb') as features_file:
        pickle.dump(feature_schemas, features_file)

def preprocess(images, labels):
  # rescales from [0, 255] to [-1, 1], equivalent to:  images = (images / 127.5) - 1
   images = preprocess_input(images)
   return images, labels



def get_model():
    model = Sequential()
    model.add(PRETRAINED_MODEL)
    model.add(layers.GlobalAveragePooling2D(name='gap'))
    model.add(tf.keras.layers.Dense(512, activation='relu'))
    model.add(tf.keras.layers.Dropout(0.3))
    model.add(tf.keras.layers.Dense(512, activation='relu', name="last_relu"))
    model.add(tf.keras.layers.Dropout(0.3, name="last_dropout"))
    model.add(tf.keras.layers.Dense(5, activation='softmax',name='classifier_hidden'))
    model.summary()
    return model

def read_features_from_file(filename):
    with open(filename, 'rb') as features_file:
        feature_schemas = pickle.load(features_file)
    return feature_schemas

def read_index_from_file(filename):
    with open(BASE_DIR + filename, 'rb') as index_file:
        index = pickle.load(index_file)
    return index

def save_index_into_file(filename,index):
    with open(BASE_DIR + filename, 'wb') as index_file:
        pickle.dump(index, index_file)


# READ TRAINING, VALIDATION AND DISTRACTOR USING FLOW FROM DIRECTORY
# IT IS USED TO PERFORM DATA AUGMENTATION (FOR TRAINING)
# source: https://keras.io/api/preprocessing/image/
def read_data(shuffle=True):
    train_datagen = image.ImageDataGenerator(
        preprocessing_function=preprocess_input,
        rotation_range=40,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=20,
        zoom_range=0.2,
        horizontal_flip=True,
        validation_split=0.2)

    test_datagen = image.ImageDataGenerator(preprocessing_function=preprocess_input)

    validation_datagen = image.ImageDataGenerator(preprocessing_function=preprocess_input, validation_split=0.2)

    train_generator = train_datagen.flow_from_directory(
        TRAINING_SET,
        seed=123,
        target_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='sparse',
        shuffle=shuffle,
        subset='training')

    validation_generator = validation_datagen.flow_from_directory(
        TRAINING_SET,
        seed=123,
        target_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='sparse',
        shuffle=shuffle,
        subset='validation')

    distractor_dataset = test_datagen.flow_from_directory(
        DISTRACTOR_SET,
        shuffle=shuffle,
        target_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE)

    return validation_generator, train_generator, distractor_dataset


# READ TRAINING, VALIDATION AND DISTRACTOR USING FLOW FROM DIRECTORY
# IT IS USED TO CREATE THE FEATURE SCHEMAS DURING EXTRACTION
def read_data_correct():
    datagen = image.ImageDataGenerator(preprocessing_function=preprocess_input)

    train_generator = datagen.flow_from_directory(
        TRAINING_SET,
        target_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='sparse',
        shuffle=False)

    test_generator = datagen.flow_from_directory(
        VALIDATION_SET,
        target_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='sparse',
        shuffle=False)

    distractor_dataset = datagen.flow_from_directory(
        DISTRACTOR_SET,
        shuffle=False,
        target_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE)

    return test_generator, train_generator, distractor_dataset


def count_label(labels):
    drawings = 0
    engraving = 0
    iconography = 0
    painting = 0
    sculpture = 0
    for label in labels:
        label = list(label)
        drawings += label.count(0)
        engraving += label.count(1)
        iconography += label.count(2)
        painting += label.count(3)
        sculpture += label.count(4)
    return drawings, engraving, iconography, painting, sculpture

def get_list_labels(feature_schemas):
  list_labels = list()
  for feature_schema in feature_schemas:
    list_labels.append(feature_schema.label)
  return list_labels
