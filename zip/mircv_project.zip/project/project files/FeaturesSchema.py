import numpy as np

class FeaturesSchema:
  def __init__(self, tensor, img_id, label):
    self.tensor = tensor
    self.img_id = img_id
    self.label = label

  def distance_from(self, schema):
    # return np.linalg.norm(self.tensor - schema.tensor)
    return 1 - np.dot(np.array(self.tensor), np.array(schema.tensor))/np.linalg.norm(np.array(self.tensor))
