from VPTree import VPTree
from utility import *
from CONSTANTS import *
from FeaturesSchema import FeaturesSchema

if __name__ == '__main__':
    feature_schemas = read_features_from_file(BASE_DIR+"features_extracted_until_gap_layer")
    vptree = VPTree(feature_schemas, BUCKET_SIZE)
    save_index_into_file("index", vptree)