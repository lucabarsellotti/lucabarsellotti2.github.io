package controller;

import java.io.IOException;

import bean.Customer;
import bean.RestaurantManager;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ui.App;

public class MainScenarioController {
	@FXML
	private Button customerButton;
	@FXML
	private Button restaurantManagerButton;

	@FXML
	private void initialize() {

		// load the images inside the buttons
		Image customerImage = new Image(getClass().getResourceAsStream("/images/customer.png"));
		ImageView imageView = new ImageView(customerImage);
		imageView.setFitHeight(250);
		imageView.setFitWidth(250);
		customerButton.setGraphic(imageView);

		Image restaurantManagerImage = new Image(getClass().getResourceAsStream("/images/restaurantManager.png"));
		imageView = new ImageView(restaurantManagerImage);
		imageView.setFitHeight(250);
		imageView.setFitWidth(250);
		restaurantManagerButton.setGraphic(imageView);

		customerButton.setOnAction((event) -> {
			try {
				App.setUser(new Customer());
				App.getStage().setScene(new Scene(App.loadFXML("loginScenario")));
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

		restaurantManagerButton.setOnAction(actionEvent -> {
			try {
				App.setUser(new RestaurantManager());
				App.getStage().setScene(new Scene(App.loadFXML("loginScenario")));
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

	}
}
