package controller;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bean.Customer;
import bean.Food;
import bean.OrderBill;
import bean.RestaurantManager;
import dao.FoodOrderBillDAO;
import dao.OrderBillDAO;
import entityManager.FoodOrderBillEM;
import entityManager.OrderBillEM;
import entityManager.UserEM;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Popup;
import ui.App;
import ui.Cart;

public class HomeController {



	@FXML
	private Button restaurantsButton;
	@FXML
	private Button myOrdersButton;
	@FXML
	private Button logoutButton;
	@FXML
	private ScrollPane container;
	@FXML
	private Button searchButton;
	@FXML
	private TextField searchRestaurantTextField;
	@FXML
	private AnchorPane scenario;

	//object that contains the restaurant selected by the user
	RestaurantManager restaurantSelected;

	// Elements to create the cart
	Label cartLabel;
	Cart cart;
	ScrollPane cartScrollPane;
	Button nextButton;
	Label totalPriceLabel;
	boolean totalPriceLabelAlreadyAdded = false;

	boolean cartScollPaneAlreadyAdded = false;

	@FXML
	private void initialize() {
		initializeCartObjects();
		// the first scenario when a user enters the application is the restaurant
		// scenario
		setRestaurantScenario();

		restaurantsButton.setOnAction((event) -> {
			setRestaurantScenario();
		});

		myOrdersButton.setOnAction(actionEvent -> {
			setMyordersScenario();
		});

		logoutButton.setOnAction(actionEvent -> {
			logout();
		});
	}

	private void setMyordersScenario() {
		scenario.getChildren().remove(cartScrollPane);
		scenario.getChildren().remove(nextButton);
		scenario.getChildren().remove(cartLabel);
		scenario.getChildren().remove(totalPriceLabel);
		restaurantsButton.setStyle("-fx-body-color: linear-gradient(\n" + "        to bottom,\n"
				+ "        derive(-fx-color,34%) 0%,\n" + "        derive(-fx-color,-18%) 100%\n" + "    );");
		myOrdersButton.setStyle("-fx-background-color: RED;");
		showOrders();

	}

	private void logout() {
		try {
			App.getStage().setScene(new Scene(App.loadFXML("loginScenario")));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void setRestaurantScenario() {
		restaurantsButton.setStyle("-fx-background-color: RED;");
		myOrdersButton.setStyle("-fx-body-color: linear-gradient(\n" + "        to bottom,\n"
				+ "        derive(-fx-color,34%) 0%,\n" + "        derive(-fx-color,-18%) 100%\n" + "    );");
		scenario.getChildren().remove(cartScrollPane);
		scenario.getChildren().remove(nextButton);
		scenario.getChildren().remove(cartLabel);
		scenario.getChildren().remove(totalPriceLabel);
		cartScollPaneAlreadyAdded = false;
		totalPriceLabelAlreadyAdded = false;
		showRestaurants("");
	}

	private void showOrders() {
		searchButton.setDisable(true);
		searchButton.setText("SEARCH");
		searchRestaurantTextField.setEditable(false);
		searchRestaurantTextField.setText("These are your orders! Click on one of them for further details");

		container.setPrefWidth(600);
		//the grid will contain every order made by the customer
		GridPane grid = new GridPane();

		UserEM userEM = new UserEM();
		//retrieve the customer from the db
		//this has to be done, otherwise we don't see the new orders made by the customer
		Customer c = (Customer) userEM.findById(App.getUser().getId());
		List<OrderBill> bills = c.getOrderBills();
		bills.sort((x, y) -> y.getDateTime().compareTo(x.getDateTime()));
		if (bills != null) {
			int counter = 0;
			for (OrderBill b : bills) {
				//for each order made by the customer, display a brief summary
				String restaurantName = b.getRestaurantManager().getName();
				LocalDateTime orderDate = b.getDateTime();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
				String date = formatter.format(orderDate);
				float price = 0;
				for (Object[] obj : b.getFoodsAndQuantity()) {
					Food f = new Food((Food) obj[0]);
					price += f.getPrice() * Integer.parseInt(obj[1].toString());
				}

				Button button = new Button(restaurantName + " - " + date + " - " + price + " €");
				button.setOnAction(actionEvent -> {
					//if the order button is clicked, show the details of the order
					showOrderDetail(b);
				});
				button.setPrefWidth(600);
				button.setPrefHeight(50);
				button.setStyle("-fx-alignment: CENTER");
				grid.add(button, 1, counter);
				counter++;

			}
		}
		container.setFitToWidth(true);
		grid.setVgap(10);
		container.setContent(grid);

	}

	private void showOrderDetail(OrderBill orderBill) {
		Popup popup = new Popup();
		AnchorPane ap = new AnchorPane();
		ap.setPrefWidth(300);
		ap.setPrefHeight(450);
		ap.setStyle("-fx-background-color: white;");
		popup.getContent().add(ap);
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setPrefWidth(300);
		scrollPane.setPrefHeight(350);
		scrollPane.setFitToWidth(true);
		scrollPane.setLayoutY(50);
		GridPane gridPane = new GridPane();
		int counter = 0;

		Label title = new Label("BILL");
		title.setStyle("-fx-alignment: CENTER; -fx-text-fill:RED;-fx-font-size: 22px;");
		title.setPrefWidth(250);
		title.setPrefHeight(50);
		Button closeButton1 = new Button("CLOSE");
		closeButton1.setLayoutY(450);
		closeButton1.setPrefWidth(300);
		closeButton1.setStyle("-fx-font-size: 22px;");
		closeButton1.setOnAction((event) -> {
			//if the order detail popup is closed, the other graphic elements are enabled
			for(Node node : App.getStage().getScene().getRoot().getChildrenUnmodifiable()) {
				node.setDisable(false);
			}
			popup.hide();
		});
		;

		Button closeButton2 = new Button("X");
		closeButton2.setStyle("-fx-font-size: 22px;-fx-text-fill: RED;");
		closeButton2.setLayoutX(250);
		closeButton2.setPrefWidth(50);
		closeButton2.setOnAction((event) -> {
			//if the order detail popup is closed, the other graphic elements are enabled
			for(Node node : App.getStage().getScene().getRoot().getChildrenUnmodifiable()) {
				node.setDisable(false);
			}
			popup.hide();
		});

		popup.getContent().add(title);
		popup.getContent().add(closeButton1);
		popup.getContent().add(closeButton2);
		float totalPrice = 0;
		for (Object[] obj : orderBill.getFoodsAndQuantity()){

			//for each food of the order, we retrieve the price and the quantity
			Food f = new Food((Food)obj[0]);
			System.out.println("Food -> " + f.getName() + " quantity -> " + obj[1]);
			Label l = new Label(obj[1] + " x " + f.getName());
			l.setStyle("-fx-alignment: CENTER;-fx-border-color:black;-fx-font-size: 15px;");
			l.setPrefWidth(300);
			gridPane.add(l, 1, counter);
			totalPrice += f.getPrice() * Integer.parseInt(obj[1].toString());
			counter++;
		}


		Label tp = new Label("Total price: " + totalPrice + "€");
		tp.setStyle("-fx-alignment: CENTER; -fx-text-fill:RED;-fx-border-color:black;-fx-font-size: 22px;");
		tp.setLayoutY(400);
		tp.setPrefWidth(300);
		tp.setPrefHeight(50);
		gridPane.setVgap(10);
		popup.getContent().add(tp);
		gridPane.setVgap(10);

		scrollPane.setContent(gridPane);

		popup.getContent().add(scrollPane);
		popup.show(App.getStage());
		//when the order detail popup is showing, the other graphic elements are disabled
		for(Node node : App.getStage().getScene().getRoot().getChildrenUnmodifiable()) {
			node.setDisable(true);
		}
	}

	private void showRestaurants(String name) {
		searchButton.setOnAction((event) -> {
			showRestaurants(searchRestaurantTextField.getText().toLowerCase());
		});
		searchButton.setDisable(false);
		searchButton.setText("SEARCH");
		searchRestaurantTextField.setEditable(true);
		searchRestaurantTextField.setText("");

		scenario.getChildren().remove(cartLabel);
		scenario.getChildren().remove(cartScrollPane);
		scenario.getChildren().remove(nextButton);
		scenario.getChildren().remove(totalPriceLabel);

		totalPriceLabelAlreadyAdded = false;
		cartScollPaneAlreadyAdded = false;

		container.setPrefWidth(600);
		//the grid that contains all the restaurants
		GridPane grid = new GridPane();
		UserEM userEM = new UserEM();
		List<RestaurantManager> restaurants = userEM.showRestaurants();
		if (restaurants != null) {
			int counter = 0;
			for (RestaurantManager r : restaurants) {
				//for each restaurant that contains "name" in its name
				// we retrieve its info and add it to the gui

				String restaurantName = r.getName().toLowerCase();
				if (restaurantName.contains(name)) {
					Button button = new Button(restaurantName);
					Tooltip tt = new Tooltip();
					tt.setText(r.getDescription()+". TELEPHONE: "+r.getPhone());
					button.setTooltip(tt);
					button.setPrefWidth(600);
					button.setPrefHeight(50);
					button.setStyle("-fx-alignment: CENTER");
					button.setOnAction(actionEvent -> {
						restaurantSelected = r;
						createMenu();
					});

					grid.add(button, 1, counter);
					counter++;
				}
			}
		}
		grid.setVgap(10);
		container.setFitToWidth(true);
		container.setContent(grid);
	}

	private void createMenu() {
		//create the menu for the selected restaurant

		//the search button becomes a back button
		searchButton.setText("BACK");
		container.setPrefWidth(350);


		searchButton.setOnAction(actionEvent -> {
			//if the back button is clicked, then go back to the restaurant screen
			//removing all the elements from the gui that we don't need in the restaurant screen
			scenario.getChildren().remove(cartLabel);
			scenario.getChildren().remove(cartScrollPane);
			scenario.getChildren().remove(nextButton);
			scenario.getChildren().remove(totalPriceLabel);

			cartScollPaneAlreadyAdded = false;
			totalPriceLabelAlreadyAdded = false;

			showRestaurants("");
		});

		//create a new cart
		cart = new Cart();

		//the next button is disabled until there are no objects in the cart
		nextButton.setDisable(true);
		scenario.getChildren().add(nextButton);

		searchRestaurantTextField.setText(restaurantSelected.getName());
		searchRestaurantTextField.setEditable(false);

		//grid that contains the food in the selected restaurant menu
		GridPane grid = new GridPane();
		int counter = 0;
		for (Food f : restaurantSelected.getFoods()) {
			Button button = new Button(f.getName() + "-" + f.getPrice() + "€");
			button.setPrefWidth(350);
			button.setPrefHeight(50);
			button.setStyle("-fx-alignment: CENTER; -fx-font-size: 16px;");
			//if a food is clicked we add it to the cart
			button.setOnAction(actionEvent -> {
				addToCart(f);
			});

			grid.add(button, 1, counter);
			counter++;
		}
		grid.setVgap(10);
		container.setContent(grid);
		scenario.getChildren().add(cartLabel);
	}

	private void addToCart(Food food) {
		cart.add(food);
		updateCart();
	}

	private void updateCart() {
		if (!cartScollPaneAlreadyAdded) {
			cartScrollPane.setPrefWidth(250);
			cartScrollPane.setPrefHeight(370);
			cartScrollPane.setLayoutY(165);
			cartScrollPane.setLayoutX(350);
			scenario.getChildren().add(cartScrollPane);
			cartScollPaneAlreadyAdded = true;
		}
		if (!totalPriceLabelAlreadyAdded) {
			scenario.getChildren().add(totalPriceLabel);
			totalPriceLabelAlreadyAdded = true;
		}

		GridPane grid = new GridPane();
		//retrieve all the food inside the cart and display them
		HashMap<Food, Integer> foods = cart.getFoods();
		int counter = 0;
		float totalPrice = 0;
		for (Map.Entry<Food, Integer> entry : foods.entrySet()) {
			float totalPriceForSingleFood = entry.getKey().getPrice() * entry.getValue();
			//for each food inside the cart we ass a minus button to remove one instance of it
			Button minusButton = new Button("-");
			minusButton.setStyle("-fx-font-size: 12pt; -fx-text-fill:black;-fx-font-weight: bold;");
			minusButton.setPrefHeight(15);
			minusButton.setOnAction(actionEvent -> {
				cart.remove(entry.getKey());
				updateCart();
			});
			totalPrice += totalPriceForSingleFood;
			Label l = new Label(
					entry.getValue() + " x " + entry.getKey().getName() + " - " + totalPriceForSingleFood + "€");

			l.setStyle("-fx-alignment: CENTER;-fx-border-color:black;-fx-font-size: 15px;");
			l.setGraphic(minusButton);
			l.setContentDisplay(ContentDisplay.RIGHT);
			l.setPrefWidth(250);
			grid.add(l, 1, counter);
			grid.add(minusButton, 1, counter);
			counter++;
		}

		totalPriceLabel.setText("Total price: " + totalPrice + "€");
		if (counter > 0)
			//if there is at least one food in the cart, enable the next button
			nextButton.setDisable(false);
		cartScrollPane.setFitToWidth(true);
		grid.setVgap(10);
		cartScrollPane.setContent(grid);

	}

	private void showBill(String buttonText) {
		Popup popup = new Popup();
		AnchorPane ap = new AnchorPane();
		//create the popup for the bill
		ap.setPrefWidth(300);
		ap.setPrefHeight(450);
		ap.setStyle("-fx-background-color: white;");
		popup.getContent().add(ap);
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setPrefWidth(300);
		scrollPane.setPrefHeight(350);
		scrollPane.setFitToWidth(true);
		scrollPane.setLayoutY(50);
		GridPane gridPane = new GridPane();

		HashMap<Food, Integer> foods = cart.getFoods();
		int counter = 0;

		Label title = new Label("BILL");
		title.setStyle("-fx-alignment: CENTER; -fx-text-fill:RED;-fx-font-size: 22px;");
		title.setPrefWidth(250);
		title.setPrefHeight(50);
		Button confirmButton = new Button(buttonText);
		confirmButton.setLayoutY(450);
		confirmButton.setPrefWidth(300);
		confirmButton.setStyle("-fx-font-size: 22px;");
		confirmButton.setOnAction((event) -> {

			OrderBill orderBill = new OrderBill();
			orderBill.setDateTime(LocalDateTime.now());
			orderBill.setCustomer((Customer) App.getUser());
			orderBill.setRestaurantManager(restaurantSelected);
			//insert the order bill in the db
			OrderBillEM orderBillEM = new OrderBillEM();
			int result = orderBillEM.insert(orderBill);
			orderBill.setId(result);
			FoodOrderBillEM foodOrderBillEM = new FoodOrderBillEM();
			// ======================Save the FoodOrderBill into level database and SQL
			for (Map.Entry<Food, Integer> entry : foods.entrySet())
				FoodOrderBillDAO.saveOrderedFood(foodOrderBillEM.addFood(orderBill, entry.getKey(), entry.getValue()));
			popup.hide();

			// ==============================save orderBill in key-value database
			OrderBillDAO.saveOrderedBill(orderBill);
			//if the order bill popup is closed, the other graphic elements are enabled
			for(Node node : App.getStage().getScene().getRoot().getChildrenUnmodifiable()) {
				node.setDisable(false);
			}
			showRestaurants("");
		});

		Button closeButton = new Button("X");
		closeButton.setStyle("-fx-font-size: 22px;-fx-text-fill: RED;");
		closeButton.setLayoutX(250);
		closeButton.setPrefWidth(50);
		closeButton.setOnAction((event) -> {
			popup.hide();
			//if the order bill popup is closed, the other graphic elements are enabled
			for(Node node : App.getStage().getScene().getRoot().getChildrenUnmodifiable()) {
				node.setDisable(false);
			}
		});

		popup.getContent().add(title);
		popup.getContent().add(confirmButton);
		popup.getContent().add(closeButton);
		float totalPrice = 0;
		for (Map.Entry<Food, Integer> entry : foods.entrySet()) {
			//visualize a brief summary of the order
			float totalPriceForSingleFood = entry.getKey().getPrice() * entry.getValue();
			totalPrice += totalPriceForSingleFood;
			Label l = new Label(
					entry.getValue() + " x " + entry.getKey().getName() + " - " + totalPriceForSingleFood + "€");
			l.setStyle("-fx-alignment: CENTER;-fx-border-color:black;-fx-font-size: 15px;");
			l.setPrefWidth(300);
			gridPane.add(l, 1, counter);
			counter++;
		}
		Label tp = new Label("Total price: " + totalPrice + "€");
		tp.setStyle("-fx-alignment: CENTER; -fx-text-fill:RED;-fx-border-color:black;-fx-font-size: 22px;");
		tp.setLayoutY(400);
		tp.setPrefWidth(300);
		tp.setPrefHeight(50);
		popup.getContent().add(tp);
		gridPane.setVgap(10);
		scrollPane.setContent(gridPane);
		popup.getContent().add(scrollPane);

		popup.show(App.getStage());
		//when the order bill popup is showing, the other graphic elements are disabled
		for(Node node : App.getStage().getScene().getRoot().getChildrenUnmodifiable()) {
			node.setDisable(true);
		}

	}


	private void initializeCartObjects(){
		cartLabel = new Label("CART");
		cartLabel.setPrefWidth(250);
		cartLabel.setPrefHeight(40);

		cartLabel.setLayoutY(122);
		cartLabel.setLayoutX(350);
		cartLabel.setStyle("-fx-alignment: CENTER; -fx-font-weight: bold;");
		totalPriceLabel = new Label("Total price:");
		totalPriceLabel.setLayoutY(533);
		totalPriceLabel.setPrefWidth(250);
		totalPriceLabel.setPrefHeight(30);
		totalPriceLabel.setLayoutX(350);
		totalPriceLabel.setStyle("-fx-text-fill: RED; -fx-alignment: CENTER;-fx-font-size: 18px;");
		nextButton = new Button("NEXT");
		nextButton.setPrefWidth(250);
		nextButton.setPrefHeight(40);
		nextButton.setLayoutY(563);
		nextButton.setLayoutX(350);
		nextButton.setDisable(true);
		nextButton.setStyle("-fx-alignment: CENTER; -fx-font-size:20px; -fx-border-color:BLACK;");
		nextButton.setOnAction((actionEvent -> {
			showBill("CONFIRM");
		}));

		cart = new Cart();
		cartScrollPane = new ScrollPane();
	}
}
