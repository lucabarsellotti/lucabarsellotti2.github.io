package controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import bean.Food;
import bean.FoodOrderBill;
import bean.OrderBill;
import bean.RestaurantManager;
import dao.FoodDAO;
import dao.FoodOrderBillDAO;
import dao.OrderBillDAO;
import entityManager.FoodEM;
import entityManager.OrderBillEM;
import entityManager.UserEM;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import ui.App;
import ui.GUIUtil;

public class AdminController {
	// ========================================fields
	public RestaurantManager rm;
	// ==============================================
	@FXML
	Button myFoodsButton;

	@FXML
	Button logoutButton;
	@FXML
	Button statisticsButton;
	@FXML
	Label infoLabel;
	@FXML
	Button ordersButton;
	@FXML
	ScrollPane container;
	@FXML
	AnchorPane scenario;
	@FXML
	AnchorPane paneInsideScroll;

	// gui elements
	Group group;
	boolean groupAlreadyAdded;

	@FXML
	private void initialize() {
		group = new Group();
		infoLabel.setStyle("-fx-alignment: CENTER;");
		// first screen that the restaurant manager sees, it's the showFoodsFromMenu
		showFoodsFromMenu();

		statisticsButton.setOnAction(actionEvent -> {
			showStatistics();
		});
		logoutButton.setOnAction(actionEvent -> {
			logout();
		});
		myFoodsButton.setOnAction(actionEvent -> {
			showFoodsFromMenu();
		});
		ordersButton.setOnAction(actionEvent -> {
			showOrders();
		});
	}

	private void showFoodsFromMenu() {
		myFoodsButton.setStyle("-fx-background-color: RED;");
		ordersButton.setStyle("-fx-body-color: linear-gradient(\n" + "        to bottom,\n"
				+ "        derive(-fx-color,34%) 0%,\n" + "        derive(-fx-color,-18%) 100%\n" + "    );");
		statisticsButton.setStyle("-fx-body-color: linear-gradient(\n" + "        to bottom,\n"
				+ "        derive(-fx-color,34%) 0%,\n" + "        derive(-fx-color,-18%) 100%\n" + "    );");

		UserEM userEM = new UserEM();
		// get an updated version of restaurantManager to show the foods updated!!
		rm = (RestaurantManager) userEM.findById(App.getUser().getId());
		GridPane grid = new GridPane();
		int counter = 0;

		infoLabel.setText(
				"These are the food from your menu. To add a new one, just insert its name and price and click the insert button!");
		// creating the gui elements for adding a new food
		Label foodNameLabel = new Label("Name:");
		Label foodPriceLabel = new Label("Price: ");
		foodNameLabel.setPrefWidth(40);
		foodNameLabel.setPrefHeight(20);
		foodPriceLabel.setPrefWidth(40);
		foodPriceLabel.setPrefHeight(20);
		foodNameLabel.setLayoutY(130);
		foodNameLabel.setLayoutX(40);
		foodPriceLabel.setLayoutX(265);
		foodPriceLabel.setLayoutY(130);
		TextField newFoodName = new TextField();
		newFoodName.setPrefWidth(175);
		newFoodName.setLayoutX(80);
		newFoodName.setLayoutY(127);
		newFoodName.setPrefHeight(20);
		newFoodName.setStyle("-fx-alignment: CENTER;");
		TextField newFoodPrice = new TextField();
		newFoodPrice.setPrefWidth(170);
		newFoodPrice.setLayoutY(127);
		newFoodPrice.setStyle("-fx-alignment: CENTER;");
		newFoodPrice.setLayoutX(300);
		newFoodPrice.setPrefHeight(20);
		Button insertButton = new Button("INSERT");
		insertButton.setPrefWidth(70);
		insertButton.setPrefHeight(20);
		insertButton.setLayoutX(485);
		insertButton.setLayoutY(127);
		Separator separator = new Separator();
		separator.setPrefWidth(600);
		separator.setLayoutY(154);
		separator.setStyle("-fx-background-color: BLACK;");
		if (!groupAlreadyAdded) {
			group.getChildren().addAll(foodNameLabel, foodPriceLabel, newFoodPrice, newFoodName, separator,
					insertButton);
			scenario.getChildren().add(group);
			groupAlreadyAdded = true;
		}
		container.setLayoutY(160);
		container.setPrefHeight(441);

		insertButton.setOnAction(actionEvent -> {
			// insert the new food in the db
			FoodEM foodEM = new FoodEM();
			if (newFoodName.getText().equals("")) {
				GUIUtil.showAlert("Food must have a name", "You are trying to insert a food with no name!", "", 1);
			} else {
				float foodPrice = 0;
				try {
					foodPrice = Float.parseFloat(newFoodPrice.getText());
				} catch (NumberFormatException e) {
					GUIUtil.showAlert("Problem with the price of the food",
							"A positive number must be inserted as price!", "", 1);

				}
				if (foodPrice < 0) {
					GUIUtil.showAlert("Problem with the price of the food",
							"A positive number must be inserted as price!", "", 1);
				} else {
					if (foodPrice != 0) {
						Food food = new Food(rm, newFoodName.getText(), foodPrice);
						// insert the food in the db if all the fields are correct
						int result = foodEM.insert(food);
						food = foodEM.getRestaurantFood(rm, food.getName());
						// save food in key-value data-base
						FoodDAO.saveFood(food);
						//
						if (result >= 0) {
							GUIUtil.showAlert("Food succesfully inserted!", "The food has been added to your menu!", "",
									2);
							// once the food has been added, we update the graphics with the new one
							showFoodsFromMenu();
						} else {
							GUIUtil.showAlert("Food already in menu!", "The food is already contained in the menu!", "",
									2);

						}
					}
				}
			}

		});

		for (Food f : rm.getFoods()) {
			// for each food of the restaurant, we allow the user to modify the price and
			// the name of it
			String foodName = f.getName();
			String foodPrice = "" + f.getPrice();
			TextField foodNameTextField = new TextField(foodName);
			foodNameTextField.setPrefWidth(225);
			foodNameTextField.setPrefHeight(50);
			foodNameTextField.setStyle("-fx-alignment: CENTER;");
			TextField foodPriceTextField = new TextField(foodPrice);
			foodPriceTextField.setPrefWidth(225);
			foodPriceTextField.setPrefHeight(50);
			foodPriceTextField.setStyle("-fx-alignment: CENTER;");
			Button updateButton = new Button("UPDATE");
			updateButton.setPrefWidth(75);
			updateButton.setPrefHeight(50);
			updateButton.setStyle("-fx-alignment: CENTER;");
			updateButton.setOnAction(actionEvent -> {

				float newPrice = 0;
				String newName = "";
				try {
					newPrice = Float.parseFloat(foodPriceTextField.getText());
				} catch (NumberFormatException e) {
					GUIUtil.showAlert("Problem with the price of the food", "A number must be inserted as price!", "",
							1);
					showFoodsFromMenu();
				}
				newName = foodNameTextField.getText();
				if (newName.equals("")) {
					GUIUtil.showAlert("Problem with the name of the food", "The food must have a name!", "", 1);
					showFoodsFromMenu();
				} else {
					if (newPrice > 0) {
						updateFood(f, newName, newPrice);
						GUIUtil.showAlert("Food updated", "The food has been updated!", "", 2);
						// update the value of the food in level database
						FoodDAO.updateFood(f, newName, newPrice);
					}
				}
			});
			Button deleteButton = new Button("DELETE");
			deleteButton.setPrefWidth(75);
			deleteButton.setPrefHeight(50);
			deleteButton.setStyle("-fx-alignment: CENTER;");
			deleteButton.setOnAction(actionEvent -> {
				FoodEM foodEM = new FoodEM();
				foodEM.delete(f);
				GUIUtil.showAlert("Food deleted", "The food has been deleted!", "", 2);
				showFoodsFromMenu();
				// delete the food from level database
				FoodDAO.deleteFood(f.getId());
			});
			grid.add(foodNameTextField, 1, counter);
			grid.add(foodPriceTextField, 2, counter);
			grid.add(updateButton, 3, counter);
			grid.add(deleteButton, 4, counter);
			counter++;
		}
		// grid.setHgap(10);
		grid.setVgap(10);
		container.setFitToWidth(true);
		container.setContent(grid);
	}

	private void updateFood(Food food, String name, float price) {
		setNewNameForFood(food, name);
		setNewPriceForFood(food, price);
		showFoodsFromMenu();
	}

	private void setNewNameForFood(Food f, String newName) {
		FoodEM foodEM = new FoodEM();
		foodEM.updateName(f, newName);
	}

	private void setNewPriceForFood(Food f, float newPrice) {
		FoodEM foodEM = new FoodEM();
		foodEM.updatePrice(f, newPrice);
	}

	private void showOrders() {

		ordersButton.setStyle("-fx-background-color: RED;");
		myFoodsButton.setStyle("-fx-body-color: linear-gradient(\n" + "        to bottom,\n"
				+ "        derive(-fx-color,34%) 0%,\n" + "        derive(-fx-color,-18%) 100%\n" + "    );");
		statisticsButton.setStyle("-fx-body-color: linear-gradient(\n" + "        to bottom,\n"
				+ "        derive(-fx-color,34%) 0%,\n" + "        derive(-fx-color,-18%) 100%\n" + "    );");

		scenario.getChildren().remove(group);
		groupAlreadyAdded = false;
		container.setLayoutY(127);
		container.setPrefHeight(474);

		infoLabel.setText(
				"These are the orders made for your restaurants by the clients. Click on one of them for further details!");
		// the grid contains all the orders made for the restaurant
		GridPane grid = new GridPane();

		OrderBillEM orderBillEM = new OrderBillEM();
		UserEM userEM = new UserEM();
		// get the updated version of the restaurant manager
		rm = (RestaurantManager) userEM.findById(App.getUser().getId());
		List<OrderBill> bills = orderBillEM.showAllRestaurantBills(rm);
		bills.sort((x, y) -> y.getDateTime().compareTo(x.getDateTime()));
		if (bills != null) {
			int counter = 0;
			for (OrderBill b : bills) {

				String customerName = b.getCustomer().getName();
				LocalDateTime orderDate = b.getDateTime();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
				String date = formatter.format(orderDate);
				float price = 0;
				for (Object[] obj : b.getFoodsAndQuantity()) {
					Food f = new Food((Food) obj[0]);
					price += f.getPrice() * Integer.parseInt(obj[1].toString());
				}

				Button button = new Button(customerName + " - " + date + " - " + price + "€");
				button.setOnAction(actionEvent -> {
					showOrderDetail(b);
				});
				button.setPrefWidth(600);
				button.setPrefHeight(50);
				button.setStyle("-fx-alignment: CENTER");
				grid.add(button, 1, counter);
				counter++;

			}
		}
		grid.setVgap(10);
		container.setFitToWidth(true);
		container.setContent(grid);
	}

	private void showOrderDetail(OrderBill orderBill) {
		Popup popup = new Popup();
		AnchorPane ap = new AnchorPane();
		ap.setPrefWidth(300);
		ap.setPrefHeight(450);
		ap.setStyle("-fx-background-color: white;");
		popup.getContent().add(ap);
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setPrefWidth(300);
		scrollPane.setPrefHeight(350);
		scrollPane.setFitToWidth(true);
		scrollPane.setLayoutY(50);
		GridPane gridPane = new GridPane();
		int counter = 0;

		Label title = new Label("BILL");
		title.setStyle("-fx-alignment: CENTER; -fx-text-fill:RED;-fx-font-size: 22px;");
		title.setPrefWidth(250);
		title.setPrefHeight(50);
		Button closeButton1 = new Button("CLOSE");
		closeButton1.setLayoutY(450);
		closeButton1.setPrefWidth(300);
		closeButton1.setStyle("-fx-font-size: 22px;");
		closeButton1.setOnAction((event) -> {
			popup.hide();
			for (Node node : App.getStage().getScene().getRoot().getChildrenUnmodifiable()) {
				node.setDisable(false);
			}
		});
		;

		Button closeButton2 = new Button("X");
		closeButton2.setStyle("-fx-font-size: 22px;-fx-text-fill: RED;");
		closeButton2.setLayoutX(250);
		closeButton2.setPrefWidth(50);
		closeButton2.setOnAction((event) -> {
			popup.hide();
			// if the order bill popup is closed, the other graphic elements are enabled
			for (Node node : App.getStage().getScene().getRoot().getChildrenUnmodifiable()) {
				node.setDisable(false);
			}
		});

		popup.getContent().add(title);
		popup.getContent().add(closeButton1);
		popup.getContent().add(closeButton2);
		float totalPrice = 0;
		for (Object[] obj : orderBill.getFoodsAndQuantity()) {
			Food f = new Food((Food) obj[0]);
			System.out.println("Food -> " + f.getName() + " quantity -> " + obj[1]);
			Label l = new Label(obj[1] + " x " + f.getName());
			l.setStyle("-fx-alignment: CENTER;-fx-border-color:black;-fx-font-size: 15px;");
			l.setPrefWidth(300);
			gridPane.add(l, 1, counter);
			totalPrice += f.getPrice() * Integer.parseInt(obj[1].toString());
			counter++;
		}
		Label tp = new Label("Total price: " + totalPrice + "€");
		tp.setStyle("-fx-alignment: CENTER; -fx-text-fill:RED;-fx-border-color:black;-fx-font-size: 22px;");
		tp.setLayoutY(400);
		tp.setPrefWidth(300);
		tp.setPrefHeight(50);

		popup.getContent().add(tp);
		scrollPane.setContent(gridPane);
		popup.getContent().add(scrollPane);
		// when the order bill popup is showing, the other graphic elements are disabled
		for (Node node : App.getStage().getScene().getRoot().getChildrenUnmodifiable()) {
			node.setDisable(true);
		}
		popup.show(App.getStage());
	}

	private void showStatistics() {
		statisticsButton.setStyle("-fx-background-color: RED;");
		myFoodsButton.setStyle("-fx-body-color: linear-gradient(\n" + "        to bottom,\n"
				+ "        derive(-fx-color,34%) 0%,\n" + "        derive(-fx-color,-18%) 100%\n" + "    );");
		ordersButton.setStyle("-fx-body-color: linear-gradient(\n" + "        to bottom,\n"
				+ "        derive(-fx-color,34%) 0%,\n" + "        derive(-fx-color,-18%) 100%\n" + "    );");

		container.setLayoutY(127);
		container.setPrefHeight(474);
		scenario.getChildren().remove(group);
		groupAlreadyAdded = false;
		VBox root = new VBox();
		root.setStyle("-fx-font-weight: bold;-fx-font-size: 20px;");

		infoLabel.setText("These are the statistics for your restaurant!");
		long totalCustomer = 0;
		float averageEarningPerCustomer = 0;
		long totalSoldPieces = 0;
		float totalEarnings = 0;

		ArrayList<OrderBill> orderBills = OrderBillDAO.getOrderBills(rm);

		totalCustomer = orderBills.size();

		for (OrderBill ob : orderBills) {
			ArrayList<FoodOrderBill> foodOrderBills = FoodOrderBillDAO.getFoodOrderBill(ob);
			for (FoodOrderBill fob : foodOrderBills) {
				totalSoldPieces += fob.getQuantity();
				totalEarnings += fob.getQuantity() * fob.getFood().getPrice();
			}
		}

		averageEarningPerCustomer = totalCustomer > 0 ? totalEarnings / totalCustomer : 0;
		Label totalCustomerLabel = new Label("Total Customers: " + totalCustomer);
		Label averageEarningPerCustomerLabel = new Label("Average earning per customer: "
				+ String.format("%.2f", averageEarningPerCustomer) + " \u20ac/customer");
		Label totalSoldPiecesLabel = new Label("Total pieces sold: " + totalSoldPieces);
		Label totalEarningsLabel = new Label("Total earnings: " + String.format("%.2f", totalEarnings) + " \u20ac");
		root.getChildren().addAll(totalCustomerLabel, averageEarningPerCustomerLabel, totalSoldPiecesLabel,
				totalEarningsLabel);
		root.setSpacing(10);
		root.setPadding(new Insets(10));
		ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
		// get all foods from the restaurant manager
		for (Food f : rm.getFoods()) {
			int countForFood = 0;
			for (OrderBill o : rm.getOrderBills()) {
				for (Food food : o.getFoods()) {
					if (food.getName().equals(f.getName())) {
						countForFood++;
					}
				}
			}
			pieChartData.add(new PieChart.Data(f.getName(), countForFood));
		}

		PieChart chart = new PieChart(pieChartData);
		chart.setTitle("Foods sold");
		root.getChildren().add(chart);
		container.setFitToWidth(true);
		container.setContent(root);

	}

	private void logout() {
		container.setLayoutY(127);
		container.setPrefHeight(474);
		if (scenario.getChildren().contains(group))
			scenario.getChildren().remove(group);
		try {
			App.getStage().setScene(new Scene(App.loadFXML("loginScenario")));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
