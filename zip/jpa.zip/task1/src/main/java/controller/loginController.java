package controller;

import java.io.IOException;

import javax.persistence.NoResultException;

import bean.Customer;
import bean.RestaurantManager;
import entityManager.UserEM;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import ui.App;
import ui.GUIUtil;

public class loginController {
	@FXML
	private Button loginButton;
	@FXML
	private Button registerButton;
	@FXML
	private Button homeButton;
	@FXML
	private TextField emailTextField;
	@FXML
	private PasswordField passwordTextField;

	@FXML
	private void initialize() {
		loginButton.setOnAction((event) -> {
			if (!checkFields()) {
				GUIUtil.showAlert("Fields error!", "MISSING FIELDS", "You have to fill-in each field to register!");
			} else {
				UserEM userEM = new UserEM();
				int resultLogin = -1;
				boolean noResultException = false;
				try {
					resultLogin = userEM.checkCredentials(emailTextField.getText(), passwordTextField.getText());
				} catch (NoResultException e) {
					GUIUtil.showAlert("Incorrect login!", "Email/Password wrong", "");
					noResultException = true;
				}

				if (resultLogin != -1) {
					if (App.getUser() instanceof Customer) {
						try {
							Customer customer = (Customer) userEM.findById(resultLogin);
							customer.setId(resultLogin);
							App.setUser(customer);
							App.getStage().setScene(new Scene(App.loadFXML("homeScenario")));
						} catch (ClassCastException e) {
							GUIUtil.showAlert("You are not a customer",
									"You are trying to login as a customer with restaurant manager credentials", "");
						} catch (IOException e) {
							e.printStackTrace();
						}

					} else {

						try {
							RestaurantManager restaurantManager = (RestaurantManager) userEM.findById(resultLogin);
							restaurantManager.setId(resultLogin);
							App.setUser(restaurantManager);
							App.getStage().setScene(new Scene(App.loadFXML("adminScenario")));
						} catch (ClassCastException e) {
							GUIUtil.showAlert("You are not a restaurant manager",
									"You are trying to login as a restaurant manager with customer credentials", "");
						} catch (IOException e) {
							e.printStackTrace();
						}

					}
				} else {
					if (!noResultException) {
						GUIUtil.showAlert("Incorrect login!", "Email/Password wrong", "");
					}
				}
			}
		});

		registerButton.setOnAction(actionEvent -> {
			try {
				App.getStage().setScene(new Scene(App.loadFXML("registerScenario")));
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

		homeButton.setOnAction(actionEvent -> {
			try {
				App.getStage().setScene(new Scene(App.loadFXML("mainScenario")));
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	private boolean checkFields() {
		if (emailTextField.getText().equals("") || passwordTextField.getText().equals(""))
			return false;
		return true;
	}
}
