package controller;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bean.Customer;
import bean.RestaurantManager;
import dao.UserDAO;
import entityManager.UserEM;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import ui.App;
import ui.GUIUtil;

public class RegisterController {
	@FXML
	private Button registerButton;
	@FXML
	private Button homeButton;
	@FXML
	private TextField emailTextField;
	@FXML
	private PasswordField passwordTextField;
	@FXML
	private TextField bankAccountTextField;
	@FXML
	private TextField phoneTextField;
	@FXML
	private TextField addressTextField;
	@FXML
	private AnchorPane container;
	@FXML
	private TextField nameTextField;

	Label label;
	DatePicker datePicker;
	TextArea textArea;

	@FXML
	private void initialize() {

		createField();

		// Handle Button event.
		registerButton.setOnAction((event) -> {
			if (!checkFields()) {
				GUIUtil.showAlert("Fields error!", "Error with the fields", "");
			} else {
				// register a new user
				// EntityManagerFactory entityManagerFactory =
				// Persistence.createEntityManagerFactory("myfood");
				UserEM userEM = new UserEM();
				int result;
				if (App.getUser() instanceof RestaurantManager) {
					// register a new RestaurantManager
					RestaurantManager restaurantManager = createRestaurantManagerInstance();
					result = userEM.insertRestaurantManager(restaurantManager);
					if (result > 0) {
						try {
							restaurantManager.setId(result);
							App.setUser(restaurantManager);
							App.getStage().setScene(new Scene(App.loadFXML("adminScenario")));
							// adding the user to the level database
							UserDAO.saveUser(restaurantManager);
						} catch (IOException e) {
							e.printStackTrace();
						}
					} else
						GUIUtil.showAlert("Error with email", "Email already used!", "");

				} else {
					// register a new Customer
					Customer customer = createCustomerInstance();
					result = userEM.insertCustomer(customer);
					if (result > 0) {
						try {
							customer.setId(result);
							App.setUser(customer);
							App.getStage().setScene(new Scene(App.loadFXML("homeScenario")));
							// adding the user to the level database
							UserDAO.saveUser(customer);
						} catch (IOException e) {
							e.printStackTrace();
						}
					} else {
						GUIUtil.showAlert("Error with email", "Email already used!", "");
					}
				}
			}
		});

		homeButton.setOnAction(actionEvent -> {
			try {
				App.getStage().setScene(new Scene(App.loadFXML("mainScenario")));
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public boolean checkFields() {
		String regex = "^(.+)@(.+)$";
		Pattern pattern = Pattern.compile(regex);
		if (App.getUser() instanceof Customer) {
			if (datePicker.getValue() == null)
				return false;
		} else {
			if (textArea.getText().equals(""))
				return false;
		}
		if (emailTextField.getText().equals("") || passwordTextField.getText().equals("")
				|| bankAccountTextField.getText().equals("") || phoneTextField.getText().equals("")
				|| addressTextField.getText().equals("") || nameTextField.getText().equals("")) {
			return false;
		}
		// check if email matches the regular expression
		Matcher matcher = pattern.matcher(emailTextField.getText());
		if (!matcher.matches())
			return false;
		// check if phone matches the regular expression
		regex = "[0-9]+";
		pattern = Pattern.compile(regex);
		matcher = pattern.matcher(phoneTextField.getText());
		if (!matcher.matches())
			return false;
		return true;
	}

	private void createField() {

		if (App.getUser() instanceof Customer) {
			// if the user is a customer then we create the datePicker field
			label = new Label("BIRTHDATE");
			datePicker = new DatePicker();
			datePicker.setLayoutX(177);
			datePicker.setLayoutY(225);
			container.getChildren().add(datePicker);
		} else {

			label = new Label("DESCRIPTION");
			textArea = new TextArea();
			textArea.setLayoutX(177);
			textArea.setLayoutY(225);
			textArea.setPrefWidth(224);
			textArea.setPrefHeight(50);
			container.getChildren().add(textArea);
		}
		label.setLayoutX(61);
		label.setLayoutY(229);
		container.getChildren().add(label);
	}

	private RestaurantManager createRestaurantManagerInstance() {
		RestaurantManager rm = new RestaurantManager();
		rm.setEmail(emailTextField.getText());
		rm.setPassword(passwordTextField.getText());
		rm.setBankAccount(bankAccountTextField.getText());
		rm.setName(nameTextField.getText());
		rm.setPhone(phoneTextField.getText());
		rm.setAddress(addressTextField.getText());
		rm.setDescription(textArea.getText());
		return rm;
	}

	private Customer createCustomerInstance() {
		Customer c = new Customer();
		c.setEmail(emailTextField.getText());
		c.setPassword(passwordTextField.getText());
		c.setBankAccount(bankAccountTextField.getText());
		c.setName(nameTextField.getText());
		c.setPhone(phoneTextField.getText());
		c.setAddress(addressTextField.getText());
		c.setBirthdate(datePicker.getValue());
		return c;
	}
}
