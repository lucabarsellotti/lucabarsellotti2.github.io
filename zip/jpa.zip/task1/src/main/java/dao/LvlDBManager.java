package dao;
import org.iq80.leveldb.*;

import java.io.File;
import java.io.IOException;

import static org.fusesource.leveldbjni.JniDBFactory.*;

public class LvlDBManager {
	private static DB db;
	private static Options options = new Options();
	private static final String PATH = "./levelDB";
	public static final String DLIM = "@:@!`";

	// =============================initialization
	public static void init() {
		Options options = new Options();
		options.createIfMissing(true);
		options.maxOpenFiles(1000);
		try {
			db = factory.open(new File(PATH), options);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// ============================================
	public static DB getDB() {
		if (db == null) {
			init();
		}
		return db;
	}

	// =================================================
	public static void closeDB() {
		try {
			db.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db = null;
	}

	// =================================================
	public static Options getOptions() {
		return options;
	}

	public static void setOptions(Options options) {
		LvlDBManager.options = options;
	}

//	public static int getId(String idType) {
//		int counterId = 0;
//		ReadOptions readOptions = new ReadOptions().snapshot(db.getSnapshot());
//		try (DBIterator iterator = db.iterator(readOptions)) {
//			iterator.seek(bytes(idType));
//			for (; iterator.hasNext(); iterator.next()) {
//				if (asString(iterator.peekNext().getKey()).contains(idType)) {
//					counterId++;
//				}
//			}
//			while (db.get(bytes(idType + counterId)) != null) {
//				counterId++;
//			}
//
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//
//		return counterId;
//	}
}