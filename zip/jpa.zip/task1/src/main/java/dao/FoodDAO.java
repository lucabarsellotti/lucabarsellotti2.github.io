package dao;
import static org.fusesource.leveldbjni.JniDBFactory.asString;
import static org.fusesource.leveldbjni.JniDBFactory.bytes;

import org.iq80.leveldb.DB;
import org.iq80.leveldb.WriteBatch;

import bean.Food;
import bean.RestaurantManager;

public class FoodDAO {

	private static DB db = LvlDBManager.getDB();

	// ==================================add a new customer to data base
	public static void saveFood(Food f) {
		db.put(bytes("food_" + f.getId()), bytes(f.toString()));
	}

	// =============delete a user from data base
	public static synchronized void deleteFood(int foodId) {
		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				WriteBatch batch = null;
				batch = db.createWriteBatch();
				batch.delete(bytes("food_" + foodId));
				db.write(batch);
			}
		});
		t.start();

	}

	// ================================
//	public static synchronized Food getFood(int foodId) {
//		Thread t = new Thread(new Runnable() {
//			@Override
//			public void run() {
//
//				String value = asString(db.get(bytes("food_" + foodId)));
//				food.parse(value);
//				return food;
//			}
//		});
//		t.start();
//	}

	// =====================update food
	public static synchronized void updateFood(Food f, String newName, float newPrice) {
		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				f.setName(newName);
				f.setPrice(newPrice);
				f.toString();
				db.delete(bytes("food_" + f.getId()));
				db.put(bytes("food_" + f.getId()), bytes(f.toString()));
			}
		});

		t.start();
	}

	// =========================================
	public static Food getFood(int foodId, RestaurantManager restaurantManager) {
		Food f = new Food();
		f.setId(foodId);
		f.setRestaurantManager(restaurantManager);
		f.parse(asString(db.get(bytes("food_" + foodId))));
		return f;
	}

}