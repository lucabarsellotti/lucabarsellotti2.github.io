package dao;

import static org.fusesource.leveldbjni.JniDBFactory.asString;
import static org.fusesource.leveldbjni.JniDBFactory.bytes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map.Entry;

import org.iq80.leveldb.DBIterator;

import bean.FoodOrderBill;
import bean.OrderBill;

public class FoodOrderBillDAO {

	// ==================================add a new OrderBill to data base
	public static void saveOrderedFood(FoodOrderBill foodOrderbill) {
		LvlDBManager.getDB().put(bytes("fob_" + foodOrderbill.getId()), bytes(foodOrderbill.toString()));
	}

	// ================================get FoodOrderBills by orderBill
	public static ArrayList<FoodOrderBill> getFoodOrderBill(OrderBill orderBill) {
		ArrayList<FoodOrderBill> foodOrderBills = new ArrayList<FoodOrderBill>();
		try (DBIterator dbIterator = LvlDBManager.getDB().iterator()) {
			dbIterator.seek(bytes("fob_"));
			while (dbIterator.hasNext()) {
				Entry<byte[], byte[]> data = dbIterator.next();
				if (asString(data.getKey()).contains("fob_")) {
					int orderBillId = Integer.parseInt(asString(data.getValue()).split(LvlDBManager.DLIM)[1]);
					if (orderBillId == orderBill.getId()) {
						FoodOrderBill foodOrderBill = new FoodOrderBill();
						foodOrderBill.setOrderBill(orderBill);
						foodOrderBill.parse(asString(data.getValue()), orderBill.getRestaurantManager());
						foodOrderBill.setId(Integer.parseInt(asString(data.getKey()).split("fob_")[1]));
						foodOrderBills.add(foodOrderBill);
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return foodOrderBills;
	}

}