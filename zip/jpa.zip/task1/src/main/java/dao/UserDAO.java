package dao;

import static org.fusesource.leveldbjni.JniDBFactory.asString;
import static org.fusesource.leveldbjni.JniDBFactory.bytes;

import java.io.IOException;

import org.iq80.leveldb.DB;
import org.iq80.leveldb.DBIterator;

import bean.Customer;
import bean.RestaurantManager;
import bean.User;

public abstract class UserDAO {
	private static DB db = LvlDBManager.getDB();

	// ==================================add a new customer to data base
	public static void saveUser(User c) {
		db.put(bytes("user_" + c.getEmail()), bytes(c.toString()));
	}

	// ================================
	public static User getUser(String email, Class<?> eClass) {
		User u = null;
		String value = asString(db.get(bytes("user_" + email)));
		if (eClass == RestaurantManager.class) {
			u = new RestaurantManager();
			u.parse(value, email);
		} else {
			u = new Customer();
			u.parse(value, email);
		}
		return u;
	}

//
//
//    public static User getUser(String email, Class<?> eClass) {
//        User u = null;
//        try {
//            db = LvlDBManager.init();
//            DBIterator iterator = db.iterator();
//            for (iterator.seekToFirst(); iterator.hasNext(); iterator.next()) {
//                System.out.println(asString(iterator.peekNext().getKey()));
//            }
//            iterator.close();
//            String value = asString(db.get(bytes("user_" + email)));
//            if (eClass == RestaurantManager.class) {
//                u = new RestaurantManager();
//                u.parse(value, email);
//            } else {
//                u = new Customer();
//                u.parse(value, email);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                db.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return u;
//    }

}