package dao;

import static org.fusesource.leveldbjni.JniDBFactory.asString;
import static org.fusesource.leveldbjni.JniDBFactory.bytes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map.Entry;

import org.iq80.leveldb.DB;
import org.iq80.leveldb.DBIterator;

import bean.OrderBill;
import bean.RestaurantManager;

public class OrderBillDAO {
	private static DB db = LvlDBManager.getDB();

	// ==================================add a new OrderBill to data base
	public static void saveOrderedBill(OrderBill c) {
		db.put(bytes("ob_" + c.getId()), bytes(c.toString()));
	}

	// ================================get OrderBills by RestaurantManager
	public static ArrayList<OrderBill> getOrderBills(RestaurantManager restaurantManager) {
		ArrayList<OrderBill> orderBills = new ArrayList<OrderBill>();
		try (DBIterator dbIterator = db.iterator()) {
			dbIterator.seek(bytes("ob_"));
			dbIterator.seekToFirst();
			while (dbIterator.hasNext()) {
				Entry<byte[], byte[]> data = dbIterator.next();
				if (asString(data.getKey()).contains("ob_")) {
					String email = asString(data.getValue()).split(LvlDBManager.DLIM)[0];
					if (email.equals(restaurantManager.getEmail())) {
						OrderBill orderBill = new OrderBill();
						orderBill.setRestaurantManager(restaurantManager);
						orderBill.parse(asString(data.getValue()));
						orderBill.setId(Integer.parseInt(asString(data.getKey()).split("ob_")[1]));
						orderBills.add(orderBill);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return orderBills;
	}

	// ===================================
//	public static OrderBill getOrderedBill(int orderBillId) {
//		OrderBill u = null;
//		String value = asString(db.get(bytes("ob_" + orderBillId)));
//		u.parse(value);
//		u.setFoods(FoodOrderBillDAO.getOrderedBillFoods(orderBillId));
//		System.out.println(value);
//		return u;
//	}

}