package entityManager;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import bean.Food;
import bean.FoodOrderBill;
import bean.OrderBill;

public class FoodOrderBillEM {

	public FoodOrderBill addFood(OrderBill orderBill, Food food, int quantity) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		// if there ins't already
		FoodOrderBill foodOrderBill = new FoodOrderBill();
		foodOrderBill.setOrderBill(orderBill);
		foodOrderBill.setFood(food);
		foodOrderBill.setQuantity(quantity);
		try {
			entityManager.getTransaction().begin();
			entityManager.merge(foodOrderBill);
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Problem in inserting a new FoodOrderBill!");
			return null;
		} finally {
			entityManager.close();
		}
		foodOrderBill.setId(getLastInsertedId());
		return foodOrderBill;
	}

	public void removeFood(OrderBill orderBill, Food food, int quantity) {
		Object[] result = null;
		EntityManager entityManager = JPAUtil.getEntityManager();
		// check if there is and how many pieces
		Query query = entityManager.createQuery(
				"SELECT fo.id,fo.quantity FROM FoodOrderBill fo WHERE fo.orderBill = :orderBill AND fo.food = :food");
		query.setParameter("orderBill", orderBill);
		query.setParameter("food", food);
		try {
			result = (Object[]) query.getSingleResult();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("No entity found");
		} finally {
			entityManager.close();
		}

		if (result == null) {
			System.out.println("Relationship not found!");
			return;
		}

		int foodOrderBillId = (Integer) result[0];
		int newQuantity = (Integer) result[1] - quantity;
		try {
			entityManager.getTransaction().begin();
			if (newQuantity > 0) {
				// delete row
				query = entityManager
						.createQuery("UPDATE FoodOrderBill fo SET fo.quantity = :quantity WHERE fo.id = :id ");
				query.setParameter("quantity", newQuantity);
				query.setParameter("id", foodOrderBillId);
				int rowsUpdated = query.executeUpdate();
				System.out.println("entities update: " + rowsUpdated);
			} else {
				// update row
				query = entityManager.createQuery("DELETE FROM FoodOrderBill fo WHERE fo.id = :id ");
				query.setParameter("id", foodOrderBillId);
				int rowsDeleted = query.executeUpdate();
				entityManager.getTransaction().commit();
			}
			entityManager.getTransaction().commit();

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Problem in deleting the FoodOrderBill!");

		} finally {
			entityManager.close();
		}

	}

	public int getLastInsertedId() {
		EntityManager entityManager = JPAUtil.getEntityManager();
		int lastFoodOrderBillId = 0;
		Query query = entityManager.createQuery("SELECT MAX(fo.id) FROM FoodOrderBill fo");
		try {
			lastFoodOrderBillId = (int) query.getSingleResult();
		} catch (NoResultException e) {
			e.printStackTrace();
			return 0;
		}
		return lastFoodOrderBillId;
	}

	public List<Object[]> getFoodsAndQuantity(OrderBill orderBill) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		Query query = entityManager.createQuery( // ,fo.quantity
				"SELECT fo.food,fo.quantity FROM FoodOrderBill fo WHERE fo.orderBill = :orderBill");
		query.setParameter("orderBill", orderBill);
		List<Object[]> resultList = query.getResultList();
		return resultList;
	}

	public List<Food> getFoods(OrderBill orderBill) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		Query query = entityManager.createQuery("SELECT fo.food FROM FoodOrderBill fo WHERE fo.orderBill = :orderBill");
		query.setParameter("orderBill", orderBill);
		List<Food> resultList = query.getResultList();
		return resultList;
	}

	public void removeByFood(Food food) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		try {
			entityManager.getTransaction().begin();
			Query query = entityManager.createQuery("DELETE FROM FoodOrderBill fo WHERE fo.food = :food ");
			query.setParameter("food", food);
			int rowsDeleted = query.executeUpdate();
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Problem in deleting the foodOrderBill!");

		} finally {
			entityManager.close();
		}
	}

}
