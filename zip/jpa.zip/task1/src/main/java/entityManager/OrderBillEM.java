package entityManager;
import java.util.List;

import javax.persistence.EntityManager;

import bean.Customer;
import bean.OrderBill;
import bean.RestaurantManager;

public class OrderBillEM {

	public int insert(OrderBill orderBill) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(orderBill);
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Problem in inserting a new orderBill!");
			return -1;
		} finally {
			entityManager.close();
		}
		return (Integer) JPAUtil.getEmFactoryObj().getPersistenceUnitUtil().getIdentifier(orderBill);
	}

	public List<OrderBill> getAll() {
		EntityManager entityManager = JPAUtil.getEntityManager();
		List<OrderBill> orderBills = entityManager.createQuery("FROM OrderBill ").getResultList();
		entityManager.close();
		return orderBills;
	}

	public List<OrderBill> showAllRestaurantBills(RestaurantManager restaurantManager) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		List<OrderBill> orderBills = entityManager.createNamedQuery("OrderBill.allRestaurantBills", OrderBill.class)
				.setParameter("restaurantManager", restaurantManager).getResultList();
		entityManager.close();
		return orderBills;
	}

	public List<OrderBill> showAllCustomerBills(Customer customer) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		List<OrderBill> orderBills = entityManager.createNamedQuery("OrderBill.allCustomerBills", OrderBill.class)
				.setParameter("customer", customer).getResultList();
		entityManager.close();
		return orderBills;
	}

}
