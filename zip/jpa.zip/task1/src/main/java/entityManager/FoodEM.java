package entityManager;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import bean.Food;
import bean.RestaurantManager;

public class FoodEM {

	/*
	 * method to insert a new food in the database
	 * 
	 * @param food the new food that has to be inserted
	 */
	public int insert(Food food) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		// -1 means that email is already used
		if (foodAlreadyExistsInRestaurant(food.getName(), food.getRestaurantManager())) {
			System.out.println("Error: food is already used in this restaurant");
			return -1;
		}
		try {
			entityManager.getTransaction().begin();
			entityManager.merge(food);
			entityManager.getTransaction().commit();

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Problem in inserting a new food!");
			return -1;
		} finally {
			entityManager.close();
		}
		return (Integer) JPAUtil.getEmFactoryObj().getPersistenceUnitUtil().getIdentifier(food);
	}

	/*
	 * method to delete a food in the database
	 * 
	 * @param food the food that has to be deleted
	 */
	public void delete(Food food) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		try {
			entityManager.getTransaction().begin();
			int foodId = (Integer) JPAUtil.getEmFactoryObj().getPersistenceUnitUtil().getIdentifier(food);
			//FoodOrderBillEM foodOrderBillEM = new FoodOrderBillEM();
			//foodOrderBillEM.removeByFood(food);
			Query query = entityManager.createQuery("DELETE FROM Food f WHERE f.id = :id ");
			query.setParameter("id", foodId);
			int rowsDeleted = query.executeUpdate();
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Problem in deleting the food!");

		} finally {
			entityManager.close();
		}
	}

	/*
	 * this method update the price of a food
	 * 
	 * @param food the food that has to be updated
	 */
	public void updatePrice(Food food, float newPrice) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		try {
			entityManager = JPAUtil.getEmFactoryObj().createEntityManager();
			entityManager.getTransaction().begin();
			int foodId = (Integer) JPAUtil.getEmFactoryObj().getPersistenceUnitUtil().getIdentifier(food);
			Query query = entityManager.createQuery("UPDATE Food f SET f.price = :price WHERE f.id = :id ");
			query.setParameter("price", newPrice);
			query.setParameter("id", foodId);
			int rowsDeleted = query.executeUpdate();
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Problem in updating the food!");

		} finally {
			entityManager.close();
		}
	}

	public void updateName(Food food, String newName) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		try {
			entityManager = JPAUtil.getEmFactoryObj().createEntityManager();
			entityManager.getTransaction().begin();
			int foodId = (Integer) JPAUtil.getEmFactoryObj().getPersistenceUnitUtil().getIdentifier(food);
			Query query = entityManager.createQuery("UPDATE Food f SET f.name = :name WHERE f.id = :id ");
			query.setParameter("name", newName);
			query.setParameter("id", foodId);
			int rowsDeleted = query.executeUpdate();
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Problem in updating the food!");

		} finally {
			entityManager.close();
		}

	}

	public Food getRestaurantFood(RestaurantManager restaurantManager, String name) {
		Food result = null;
		EntityManager entityManager = JPAUtil.getEntityManager();
		try {
			result = entityManager.createNamedQuery("Food.checkFoodRestaurant", Food.class).setParameter("name", name)
					.setParameter("restaurantManager", restaurantManager).getSingleResult();
		} catch (NoResultException nre) {
			System.out.println("Error!");
		} finally {
			entityManager.close();
		}

		return result;
	}

	private boolean foodAlreadyExistsInRestaurant(String name, RestaurantManager restaurantManager) {
		Food result = null;
		EntityManager entityManager = JPAUtil.getEntityManager();
		try {
			result = entityManager.createNamedQuery("Food.checkFoodRestaurant", Food.class).setParameter("name", name)
					.setParameter("restaurantManager", restaurantManager).getSingleResult();
		} catch (NoResultException nre) {
			System.out.println("Error!");
		} finally {
			entityManager.close();
		}
		if (result != null)
			return true;
		return false;
	}
}
