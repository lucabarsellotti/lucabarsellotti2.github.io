package ui;
import javafx.scene.control.Alert;

public class GUIUtil {

    public static void showAlert(String title, String header, String context) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(context);
        alert.showAndWait();
    }

    public static void showAlert(String title, String header, String context, int type) {
        Alert alert;
        if (type == 1)
            alert = new Alert(Alert.AlertType.WARNING);
        else
            alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(context);
        alert.showAndWait();
    }

}
