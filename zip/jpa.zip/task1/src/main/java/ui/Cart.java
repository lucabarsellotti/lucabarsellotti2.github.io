package ui;
import java.util.HashMap;

import bean.Food;

public class Cart {
    private HashMap<Food,Integer> foods;

    public Cart(){
        foods = new HashMap<>();
    }

    public void add(Food food){
        Integer number = foods.get(food);
        if(number==null)
            foods.put(food,1);
        else
            foods.put(food,number+1);
    }
    public void remove(Food food){
        Integer number = foods.get(food);
        if(number!=null) {
            number--;
            foods.put(food, number);
            if(number==0){
                foods.remove(food);
            }
        }
    }

    public HashMap<Food, Integer> getFoods() {
        return foods;
    }
}
