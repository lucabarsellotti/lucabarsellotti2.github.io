package ui;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import bean.Customer;
import bean.User;
import entityManager.JPAUtil;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {
	private static Stage guiStage;
	private static User user;
	public Customer customer;

	@Override
	public void start(Stage stage) throws IOException {
		guiStage = stage;
		stage.setResizable(false);
		stage.setTitle("My Food");
		Scene scene = new Scene(loadFXML("mainScenario"));
		stage.setScene(scene);
		stage.show();
		LogManager logManager = LogManager.getLogManager();
		Logger logger = logManager.getLogger("");
		logger.setLevel(Level.OFF);
	}

	public static Parent loadFXML(String fxml) throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(App.class.getClassLoader().getResource(fxml + ".fxml"));
		return fxmlLoader.load();
	}

	@Override
	public void stop() {
		JPAUtil.exit();
	}

	public static Stage getStage() {
		return guiStage;
	}

	public static void setUser(User u) {
		user = u;
	}

	public static User getUser() {
		return user;
	}

	public static void main(String[] args) {
		launch();
	}

}
