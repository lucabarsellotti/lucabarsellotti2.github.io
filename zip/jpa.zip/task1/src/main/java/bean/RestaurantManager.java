package bean;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
//@DiscriminatorValue(“RestaurantManager”) in RestaurantManager
public class RestaurantManager extends User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="restaurantManager_id",updatable = false,nullable = false)
    private int id;

    //RELATIONSHIP OWNED BY Food Class: here we are only linking it
    //cascade ALL-> When any operation is performed on an RestaurantManager, its foods should be updated.
    //fetchType.EAGER is used to avoid problem with retrieving foods
    @OneToMany(mappedBy = "restaurantManager", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    private List<Food> foods = new ArrayList<Food>();

    @OneToMany(mappedBy = "restaurantManager", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    @Fetch(value = FetchMode.SUBSELECT)
    private Set<OrderBill> orderBills = new HashSet<OrderBill>();

    public String description;

    public RestaurantManager(String email, String password, String bankAccount, String name, String phone, String address, List<Food> foods, String description) {
        super(email, password, bankAccount, name, phone, address);
        this.foods = foods;
        this.description = description;
    }

    public RestaurantManager() {
        super();
    }

    public List<Food> getFoods() {
        return foods;
    }

    public void setFoods(List<Food> foods) {
        this.foods = foods;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<OrderBill> getOrderBills() {
        return orderBills;
    }
}
