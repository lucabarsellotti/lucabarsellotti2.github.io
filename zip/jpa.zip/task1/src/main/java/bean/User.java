package bean;

import java.util.StringTokenizer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import dao.LvlDBManager;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
//@DiscriminatorColumn(name = “Person_Type”)
//@DiscriminatorValue(“Customer”) in Customer
//@DiscriminatorValue(“RestaurantManager”) in RestaurantManager
@Table(name = "User") // Useless because by default JPA creates a table with class's name: in this
						// case User

@NamedQueries({
		@NamedQuery(name = "User.checkCredential", query = "SELECT u FROM User u WHERE u.email = :email AND u.password = :password"),
		@NamedQuery(name = "User.checkEmail", query = "SELECT u FROM User u WHERE u.email = :email"),
		@NamedQuery(name = "User.findById", query = "SELECT u FROM User u WHERE u.id = :id") })

public abstract class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "user_id", updatable = false, nullable = false)
	private int id;

	private String email;
	private String password;
	private String bankAccount;
	private String name;
	private String phone;
	private String address;

	// TODO METHODS

	public User(String email, String password, String bankAccount, String name, String phone, String address) {
		this.email = email;
		this.password = password;
		this.bankAccount = bankAccount;
		this.name = name;
		this.phone = phone;
		this.address = address;
	}

	public User() {
		this.email = null;
		this.password = null;
		this.bankAccount = null;
		this.name = null;
		this.phone = null;
		this.address = null;
	}

	// Getters and setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	// convert fields into string in order to store it in level database as value
	// the id of key-value database is user_ + id
	public String toString() {
		return this.password + LvlDBManager.DLIM + this.bankAccount + LvlDBManager.DLIM + this.name + LvlDBManager.DLIM
				+ this.phone + LvlDBManager.DLIM + this.address;
	}

	// parse the stored value in key-value level database
	public StringTokenizer parse(String input, String email) {
		this.email = email;
		StringTokenizer st = new StringTokenizer(input, LvlDBManager.DLIM);
		this.password = st.nextToken();
		this.bankAccount = st.nextToken();
		this.name = st.nextToken();
		this.phone = st.nextToken();
		this.address = st.nextToken();
		return st;
	}
}