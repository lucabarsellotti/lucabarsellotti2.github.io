package bean;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

import dao.LvlDBManager;
import dao.UserDAO;

@Entity

@NamedQueries({
		@NamedQuery(name = "Food.checkFoodRestaurant", query = "SELECT f FROM Food f WHERE f.name = :name AND f.restaurantManager = :restaurantManager"),
		@NamedQuery(name = "Food.deleteFood", query = "DELETE FROM Food f WHERE f.id = :id ") })
public class Food {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "food_id", updatable = false, nullable = false)
	private int id;

	private String name;
	private float price;
	// bidirectional relationship with RestaurantManager
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "fk_restaurantManager",  nullable = false)
	private RestaurantManager restaurantManager;

	@OneToMany(mappedBy = "food", cascade = CascadeType.ALL)
	private Set<FoodOrderBill> foodOrderBillSet;

	public Food() {
	}

	// when we instantiate an obj of Food this is not saved into db automatically
	// this would be insert into db when we execute entityManager.persist(food) in
	// FoodEM function
	public Food(RestaurantManager restaurantManager, String name, float price) {
		this.restaurantManager = restaurantManager;
		this.name = name;
		this.price = price;
	}

	public Food(Food f) {
		this.restaurantManager = f.getRestaurantManager();
		this.name = f.getName();
		this.price = f.getPrice();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public RestaurantManager getRestaurantManager() {
		return restaurantManager;
	}

	public void setRestaurantManager(RestaurantManager restaurantManager) {
		this.restaurantManager = restaurantManager;
	}

	@Override
	public String toString() {
		return this.restaurantManager.getEmail() + LvlDBManager.DLIM + this.name + LvlDBManager.DLIM + this.price;
	}

	// parse the stored value in key-value level database
	public void parse(String input) {
		String[] splits = input.split(LvlDBManager.DLIM);
		if (this.restaurantManager == null)
			this.restaurantManager = (RestaurantManager) UserDAO.getUser(splits[0], RestaurantManager.class);
		this.name = splits[1];
		this.price = Float.parseFloat(splits[2]);

	}
}