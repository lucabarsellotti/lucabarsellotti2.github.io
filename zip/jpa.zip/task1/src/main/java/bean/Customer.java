package bean;
import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Customer extends User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "customer_id", updatable = false, nullable = false)
	private int id;

	// RELATIONSHIP OWNED BY OrderBill Class: here we are only linking it
	// cascade ALL-> When any operation is performed on an Customer, its OrderBill
	// should be updated.

	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<OrderBill> orderBills = new ArrayList<OrderBill>();

	private LocalDate birthdate;

	public Customer() {
		super();
	}

	public Customer(String email, String password, String bankAccount, String name, String phone, String address,
			LocalDate birthdate) {
		super(email, password, bankAccount, name, phone, address);
		this.birthdate = birthdate;
	}

	// Setter and getter
	public LocalDate getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(LocalDate birthdate) {
		this.birthdate = birthdate;
	}

	public List<OrderBill> getOrderBills() {
		return orderBills;
	}

	public void setOrderBills(List<OrderBill> orderBills) {
		this.orderBills = orderBills;
	}
}
