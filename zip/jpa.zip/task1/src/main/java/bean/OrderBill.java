package bean;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

import dao.LvlDBManager;
import dao.UserDAO;
import entityManager.FoodOrderBillEM;

@Entity

@NamedQueries({
		@NamedQuery(name = "OrderBill.allRestaurantBills", query = "SELECT o FROM OrderBill o WHERE o.restaurantManager = :restaurantManager "),
		@NamedQuery(name = "OrderBill.allCustomerBills", query = "SELECT o FROM OrderBill o WHERE o.customer = :customer ") })

public class OrderBill {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "orderBill_id", updatable = false, nullable = false)
	private int id;

	private LocalDateTime dateTime;
	// bidirectional relationship with Customer
	@ManyToOne
	@JoinColumn(name = "fk_customer", nullable = false)
	private Customer customer;

	// bidirectional relationship with RestauranyManager
	@ManyToOne
	@JoinColumn(name = "fk_restaurantManager", nullable = false)
	private RestaurantManager restaurantManager;

	// bidirectional relationship N->N with Food
	/*
	 * @ManyToMany(cascade = CascadeType.MERGE,fetch = FetchType.EAGER)
	 * 
	 * @JoinTable(name = "orderBill_Food", joinColumns = @JoinColumn(name =
	 * "fk_orderBill") , inverseJoinColumns = @JoinColumn(name = "fk_food") )
	 * private Set<Food> foods = new HashSet<Food>();
	 */
	@OneToMany(mappedBy = "orderBill", cascade = CascadeType.ALL)
	private Set<FoodOrderBill> foodOrderBillSet;

	public OrderBill() {
	}

	public List<Object[]> getFoodsAndQuantity() {
		FoodOrderBillEM foodOrderBillEM = new FoodOrderBillEM();
		List<Object[]> foodsQuantity = foodOrderBillEM.getFoodsAndQuantity(this);
		return foodsQuantity;
	}

	public List<Food> getFoods() {
		FoodOrderBillEM foodOrderBillEM = new FoodOrderBillEM();
		List<Food> foodsQuantity = foodOrderBillEM.getFoods(this);
		return foodsQuantity;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public float getTotalPrice() {
		float totalPrice = 0;
		for (Food f : getFoods())
			totalPrice += f.getPrice();
		return totalPrice;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public RestaurantManager getRestaurantManager() {
		return restaurantManager;
	}

	public void setRestaurantManager(RestaurantManager restaurantManager) {
		this.restaurantManager = restaurantManager;
	}

	public HashMap<String, Long> getFoodPieces() {
		ArrayList<String> foods = new ArrayList<>();
		for (Food f : getFoods())
			foods.add(f.getName());
		Map<String, Long> result = foods.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		return (HashMap<String, Long>) result;
	}

	public int getId() {
		// TODO Auto-generated method stub
		return this.id;
	}

	// convert fields into string in order to store it in level database as value
	// the id of key-value database is user_ + id
	@Override
	public String toString() {
		return this.restaurantManager.getEmail() + LvlDBManager.DLIM + this.customer.getEmail() + LvlDBManager.DLIM
				+ this.dateTime;
	}

	// parse the stored value in key-value level database
	public void parse(String value) {
		String[] splits = value.split(LvlDBManager.DLIM);
		if (this.restaurantManager == null) {
			this.restaurantManager = (RestaurantManager) UserDAO.getUser(splits[0], RestaurantManager.class);
		}
		if (this.customer == null)
			this.customer = (Customer) UserDAO.getUser(splits[1], Customer.class);
		this.dateTime = LocalDateTime.parse(splits[2]);
	}

	public void setId(int id) {
		this.id = id;
	}

}