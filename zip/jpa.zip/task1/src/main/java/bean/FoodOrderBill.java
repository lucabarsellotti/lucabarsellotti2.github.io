package bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import dao.FoodDAO;
import dao.LvlDBManager;

@SuppressWarnings("JpaModelReferenceInspection")
@Entity
@NamedQueries({
		@NamedQuery(name = "FoodOrderBill.getFoodsOrderBills", query = "SELECT fo FROM FoodOrderBill fo WHERE fo.food = :food AND fo.orderBill = :orderBill"),
		@NamedQuery(name = "FoodOrderBill.getFoods", query = "SELECT fo FROM FoodOrderBill fo WHERE fo.orderBill = :orderBill") })
public class FoodOrderBill {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "foodOrderBill_id", updatable = false, nullable = false)
	private int id;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "food_id", nullable = false)
	private Food food;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "orderBill_id", nullable = false)
	private OrderBill orderBill;

	@Column(name = "quantity", nullable = false)
	private int quantity;
	// standard constructors, getters, and setters

	public FoodOrderBill() {
	}

	public FoodOrderBill(Food food, OrderBill orderBill) {
		this.food = food;
		this.orderBill = orderBill;
	}

	public Food getFood() {
		return food;
	}

	public void setFood(Food food) {
		this.food = food;
	}

	public OrderBill getOrderBill() {
		return orderBill;
	}

	public void setOrderBill(OrderBill orderBill) {
		this.orderBill = orderBill;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	// =========================
	// convert fields into string in order to store it in level database as value
	// the id of key-value database is fob_id
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.food.getId() + LvlDBManager.DLIM + this.getOrderBill().getId() + LvlDBManager.DLIM
				+ this.getQuantity() + LvlDBManager.DLIM;
	}

	public void parse(String value, RestaurantManager restaurantManager) {
		String[] tokens = value.split(LvlDBManager.DLIM);
		this.food = FoodDAO.getFood(Integer.parseInt(tokens[0]), restaurantManager);
		this.quantity = Integer.parseInt(tokens[2]);

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}