import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.*;
import java.util.ArrayList;


public class KMeansMain {
    private static final Configuration conf = new Configuration();

    private static double oldMeanSse = 0.0;

    //execute map reduce task in order to extract k random points as initial centroids
    //the algorithm is reservoir sample
    public static boolean runSampler(String inputFileName, String outputFileName, int k) throws Exception {
        conf.set(TextOutputFormat.SEPERATOR, HDFSInterface.KEY_VALUE_SEPARATOR);
        Job job = Job.getInstance(conf, "KMeansMainSampler");

        job.getConfiguration().setInt(
                "k",
                k
        );

        job.setJarByClass(KMeansMain.class);

        job.setMapperClass(ReservoirSamplingMapper.class);
        job.setReducerClass(ReservoirSamplingReducer.class);
        job.setCombinerClass(ReservoirSamplingReducer.class);

        job.setMapOutputKeyClass(IntWritable.class);
        job.setMapOutputValueClass(CandidateCentroidWritable.class);

        //set reduce output types
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(CandidateCentroidWritable.class);

        FileInputFormat.addInputPath(job, new Path(inputFileName));
        FileOutputFormat.setOutputPath(job, new Path(outputFileName));

        //Since we need as key the offset, as number of line, in particular
        //we implement our own FormatClass, used inside both mapper and reducer of ResevoirSampling
        job.setInputFormatClass(LineInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);

        return job.waitForCompletion(true);
    }

    //execute map reduce task in order to perform one kmeans iteration
    public static boolean runKMeans(String inputFile, int dimension, int k, int iteration, double threshold) throws InterruptedException, IOException, ClassNotFoundException {
        Job job = Job.getInstance(conf, "KMeansMain");
        job.setJarByClass(KMeansMain.class);

        job.setMapperClass(KMeansMapper.class);
        job.setReducerClass(KMeansReducer.class);
        job.setCombinerClass(KMeansReducer.class);

        job.setMapOutputKeyClass(IntWritable.class);
        job.setMapOutputValueClass(AccumulatorWritable.class);

        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(AccumulatorWritable.class);

        ArrayList<AccumulatorWritable> newCentroids;

        //for the first iteration we fetch the centroids from the output file
        //of the sampler
        if(iteration == 0){
            newCentroids = HDFSInterface.readSamplesFromFile(HDFSInterface.HDFS_SAMPLE_OUT_DIR,k,conf);
        }
        //otherwise we fetch them from the output file of the previous iteration
        else{
            newCentroids = HDFSInterface.readCentroidsFromFile(HDFSInterface.HDFS_KMEANS_OUT_DIR,k,conf);
            //since output file names are always the same, we delete the previous one
            HDFSInterface.deleteCentroidsFile(HDFSInterface.HDFS_KMEANS_OUT_DIR,conf);
        }

        String[] strNewCentroids = new String[newCentroids.size()];


        //covert new centroid to array of strings, for usage of the mapper
        for(int i = 0; i < newCentroids.size(); i++){
            strNewCentroids[i] = newCentroids.get(i).getSummedPoint().toString();
        }

        job.getConfiguration().setStrings(
                "centroids",
                strNewCentroids
        );

        job.getConfiguration().setInt(
                "dimension",
                dimension
        );

        job.getConfiguration().setInt(
                "k",
                k
        );

        FileInputFormat.addInputPath(job, new Path(inputFile));
        FileOutputFormat.setOutputPath(job, new Path(HDFSInterface.HDFS_KMEANS_OUT_DIR));

        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);

        if(!job.waitForCompletion(true)) {
            System.exit(1);
        }

        //read new centroids in order to compute MeanSSE and thus the exit condition
        newCentroids = HDFSInterface.readCentroidsFromFile(HDFSInterface.HDFS_KMEANS_OUT_DIR,k,conf);

        if(iteration != 0){
            return checkExitCondition(newCentroids, threshold, k);
        }
        else{
            oldMeanSse = computeMeanSSE(newCentroids);
        }

        return false;
    }

    //compute average of sum of squared distances between each point and its closest centroid
    private static double computeMeanSSE(ArrayList<AccumulatorWritable> newCentroids) {
        double newSse = 0.0;
        int numberOfPoints = 0;

        for(AccumulatorWritable acc : newCentroids) {
            newSse += acc.getSse();
            numberOfPoints += acc.getNumberOfPoints();
        }
        return (newSse/numberOfPoints);
    }


    // Check if error is below the predefined threshold
    // true: program will stop
    // false: program will continue
    public static boolean checkExitCondition(ArrayList<AccumulatorWritable> newCentroids, double threshold, int k) throws IOException {
        double mean = computeMeanSSE(newCentroids);
        System.out.println("new mean sse: " + mean);
        double diff = oldMeanSse - mean;
        System.out.println("difference sse: " + diff);
        System.out.println("old mean sse: " + oldMeanSse);
        Statistics.saveMeanErrorStatistics(diff,conf);
        oldMeanSse = mean;

        return diff < threshold;
    }



    public static void main(String[] args) throws Exception {

        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        if (otherArgs.length != 6) {
            System.err.println("Usage: KMeans <dimension> <number_of_centroids> <number_of_iterations> <input_filepath> <output_filepath> <threshold>");
            System.exit(1);
        }

        //parse every argument
        //dimension = number of elements inside vectors
        //k = number of centroids
        //numberOfIterations = number of iterations of runKMeans to be executed
        //inputFile = file containing all points
        //threshold
        int dimension = Integer.parseInt(otherArgs[0]);
        int k = Integer.parseInt(otherArgs[1]);
        int numberOfIterations = Integer.parseInt(otherArgs[2]);
        String inputFile = otherArgs[3];
        HDFSInterface.HDFS_KMEANS_OUT_DIR = otherArgs[4];
        double threshold = Double.parseDouble(otherArgs[5]);

        //clean hdfs from old executions of the program
        HDFSInterface.resetHDFS(conf);
        long startTime = System.nanoTime();

        //Allows HDFS to open file in append mode
        conf.setBoolean("dfs.support.append", true);

        //Check if sampling has correctly fetched k random numbers
        //from the inputFile, these will be used as start-centroid
        //for the KMeans algorithm
        if (!runSampler(inputFile, HDFSInterface.HDFS_SAMPLE_OUT_DIR, k)) {
            System.out.println("An Error occurred during ReservoirSampling");
            System.exit(1);
        }

        for (int i = 0; i < numberOfIterations; i++) {
            //Check if the meanError has dropped below a certain threshold
            if (runKMeans(inputFile, dimension, k, i, threshold))
                break;
        }

        long endTime = System.nanoTime();

        //compute execution time for statistics
        long duration = (endTime - startTime);
        Statistics.saveDurationStatistics(duration,conf);

    }
}
