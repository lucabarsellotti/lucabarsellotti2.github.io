import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.URI;

public class Statistics {


    private static final String HADOOP_PATH = "hdfs://hadoop-namenode:9820/user/hadoop/";

    //Save the average of the distances from any point to its centroid-cluster, useful for statistics
    public static void saveMeanErrorStatistics(double mean, Configuration conf) throws IOException {
        Path pathStats = new Path(HADOOP_PATH + "/meanError.txt");
        FileSystem fsStats = FileSystem.get(URI.create(pathStats.toString()), conf);

        FSDataOutputStream outStats;

        if (!fsStats.exists(pathStats)) {
            System.err.println("File doesn't exist");
            outStats = fsStats.create(pathStats);
        }
        else{
            outStats = fsStats.append(pathStats);
        }

        BufferedWriter brStats = new BufferedWriter(new OutputStreamWriter(outStats, "UTF-8" ));
        brStats.append(Double.toString(mean) + '\n');
        brStats.close();
        fsStats.close();
    }

    //Save execution time for Statistics
    public static void saveDurationStatistics(long duration, Configuration conf) throws IOException {
        Path pathStats = new Path(HADOOP_PATH + "/durationStats.txt");
        FileSystem fsStats = FileSystem.get(URI.create(pathStats.toString()), conf);

        FSDataOutputStream outStats;

        if (!fsStats.exists(pathStats)) {
            System.err.println("File doesn't exist");
            outStats = fsStats.create(pathStats);
        }
        else{
            outStats = fsStats.append(pathStats);
        }

        BufferedWriter brStats = new BufferedWriter(new OutputStreamWriter(outStats, "UTF-8" ));
        brStats.append(Long.toString(duration) + '\n');
        brStats.close();
        fsStats.close();
    }
}
