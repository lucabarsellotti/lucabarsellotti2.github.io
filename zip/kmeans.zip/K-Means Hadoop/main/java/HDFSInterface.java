import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.*;
import java.net.URI;
import java.util.ArrayList;

public class HDFSInterface {

    private static final String HADOOP_PATH = "hdfs://hadoop-namenode:9820/user/hadoop/";
    public static final String HDFS_SAMPLE_OUT_DIR = "samples";
    public static String HDFS_KMEANS_OUT_DIR;
    private static final String VALUE_SEPARATOR = "/";
    public static final String KEY_VALUE_SEPARATOR = "_";

    // This function clean HDFS from eventual directories
    // and files created in precedent runs of the program

    public static void resetHDFS(Configuration conf) throws IOException {
        String path = HADOOP_PATH;
        FileSystem fs = FileSystem.get(URI.create(path), conf);
        fs.delete(new Path(HADOOP_PATH + HDFS_SAMPLE_OUT_DIR), true);
        fs.delete(new Path(HADOOP_PATH + HDFS_KMEANS_OUT_DIR), true);

        FSDataOutputStream outError;
        FSDataOutputStream outDuration;

        Path errorStats = new Path(HADOOP_PATH + "/meanError.txt");
        Path durationStats = new Path(HADOOP_PATH + "/durationStats.txt");

        if (!fs.exists(errorStats) && !fs.exists(durationStats)) {
            System.err.println("File doesn't exist");
            outError = fs.create(errorStats);
            outDuration = fs.create(durationStats);
        }
        else{
            outError = fs.append(errorStats);
            outDuration = fs.append(durationStats);
        }

        BufferedWriter brError = new BufferedWriter(new OutputStreamWriter(outError, "UTF-8" ));
        BufferedWriter brDuration = new BufferedWriter(new OutputStreamWriter(outDuration, "UTF-8" ));
        brDuration.append("/" + '\n');
        brError.append("/" + '\n');
        brError.close();
        brDuration.close();
        fs.close();
    }

    public static ArrayList<AccumulatorWritable> readSamplesFromFile(String inputFile, int k, Configuration conf) {
        ArrayList<AccumulatorWritable> tmpAccumulator = new ArrayList<>();

        try{
            String path = HADOOP_PATH + inputFile + "/part-r-00000";
            FileSystem fs = FileSystem.get(URI.create(path), conf);
            FSDataInputStream scan = fs.open(new Path(path));

            Path pathStats = new Path(HADOOP_PATH + "/statistics.txt");
            FileSystem fsStats = FileSystem.get(URI.create(pathStats.toString()), conf);

            FSDataOutputStream outStats;

            if (!fsStats.exists(pathStats)) {
                System.err.println("File doesn't exist");
                outStats = fsStats.create(pathStats);
            }
            else{
                outStats = fsStats.append(pathStats);
            }

            BufferedWriter brStats = new BufferedWriter(new OutputStreamWriter(outStats, "UTF-8" ));

            BufferedReader br = new BufferedReader(new InputStreamReader(scan));
            String line;


            line = br.readLine();
            while (line != null) {
                String[] key_value = line.split(KEY_VALUE_SEPARATOR);
                String value = key_value[1];

                value = value.replaceAll("[^\\d.,]", "");

                ArrayList<Double> coordinates = new ArrayList<>();
                for(String coord : value.split(",")) {
                    coordinates.add(Double.parseDouble(coord));
                }
                PointWritable newCentroid = new PointWritable(coordinates);

                AccumulatorWritable tmp = new AccumulatorWritable(newCentroid.d);
                tmp.addPoint(newCentroid);
                tmp.setSse(0);

                tmpAccumulator.add(tmp);

                //Write intermediate-iteration centroids for Statistics
                brStats.append(newCentroid.toString()+'\n');

                line = br.readLine();
            }
            brStats.append('\n');
            brStats.close();
            br.close();
            fs.close();
            fsStats.close();
        }catch(IOException e){
            e.printStackTrace();
        }
        return tmpAccumulator;
    }



    public static ArrayList<AccumulatorWritable> readCentroidsFromFile(String inputFile, int k,Configuration conf){
        ArrayList<AccumulatorWritable> tmpAccumulator = new ArrayList<>();

        try{
            String path = HADOOP_PATH + inputFile + "/part-r-00000";
            FileSystem fs = FileSystem.get(URI.create(path), conf);
            FSDataInputStream scan = fs.open(new Path(path));

            Path pathStats = new Path(HADOOP_PATH + "/statistics.txt");
            FileSystem fsStats = FileSystem.get(URI.create(pathStats.toString()), conf);

            FSDataOutputStream outStats;

            if (!fsStats.exists(pathStats)) {
                System.err.println("File doesn't exist");
                outStats = fsStats.create(pathStats);
            }
            else{
                outStats = fsStats.append(pathStats);
            }

            BufferedWriter brStats = new BufferedWriter(new OutputStreamWriter(outStats, "UTF-8" ));

            BufferedReader br = new BufferedReader(new InputStreamReader(scan));
            String line;

            line = br.readLine();
            while (line != null) {
                String[] keyValue_sse_num =  line.split(VALUE_SEPARATOR);
                String[] key_value = keyValue_sse_num[0].split(KEY_VALUE_SEPARATOR);
                String value = key_value[1];

                value = value.replaceAll("[^\\d.,]", "");

                ArrayList<Double> coordinates = new ArrayList<>();
                for(String coord : value.split(",")) {
                    coordinates.add(Double.parseDouble(coord));
                }
                PointWritable newCentroid = new PointWritable(coordinates);

                double sse = Double.parseDouble(keyValue_sse_num[1]);
                int num = Integer.parseInt(keyValue_sse_num[2]);

                AccumulatorWritable tmp = new AccumulatorWritable(newCentroid.d);
                tmp.addPoint(newCentroid);
                tmp.setSse(sse);
                tmp.setNumberOfPoints(num);

                tmpAccumulator.add(tmp);

                //Write intermediate-iteration centroids for Statistics
                brStats.append(newCentroid.toString()+'\n');

                line = br.readLine();
            }
            brStats.append('\n');
            brStats.close();
            br.close();
            fs.close();
            fsStats.close();
        }catch(IOException e){
            e.printStackTrace();
        }
        return tmpAccumulator;
    }


    //From iteration and iteration output-file needs to be deleted
    //Otherwise bad things(errors) will happen
    public static void deleteCentroidsFile(String inputFile,Configuration conf) throws IOException {
        String path = HADOOP_PATH + inputFile + "/part-r-00000";
        FileSystem fs = FileSystem.get(URI.create(path), conf);
        fs.delete(new Path(HADOOP_PATH + inputFile), true);
        fs.close();
    }



}
