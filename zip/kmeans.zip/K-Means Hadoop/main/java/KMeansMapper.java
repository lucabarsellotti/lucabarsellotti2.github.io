import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;

public class KMeansMapper extends Mapper<LongWritable, Text, IntWritable, AccumulatorWritable>
{
    //centroids taken from configuration
    private final ArrayList<PointWritable> centroids = new ArrayList<>();

    //utility
    private final ArrayList<Double> elements = new ArrayList<>();
    private final PointWritable thisPoint = new PointWritable();

    //output
    private final IntWritable outputKey = new IntWritable();
    private final AccumulatorWritable reducerValue = new AccumulatorWritable();

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);

        System.out.println("Setting up the mapper global variables");

        Configuration conf = context.getConfiguration();

        //get utility variables from configuration
        int dimension = conf.getInt("dimension", 3);
        int k = conf.getInt("k", 3);

        for(int i = 0; i<k; ++i)
            centroids.add(new PointWritable());

        for(int i = 0; i<dimension; ++i)
            elements.add(0.0);

        thisPoint.setD(dimension);
        reducerValue.setD(dimension);

        //Insert each centroid, represented by a string, in a PointWritable object
        String s;
        String[] coordinates = conf.getStrings("centroids");

        ArrayList<Double> centroidCoordinates = new ArrayList<>();
        centroids.clear();

        //parse centroids from configuration
        for(int i = 0; i < coordinates.length;i++){

            s = coordinates[i];

            centroidCoordinates.add(Double.parseDouble(s));

            //this way Centroids will be created only in the first execution of the map function
            if(i != 0 && (i+1) % dimension == 0) {
                centroids.add(
                        new PointWritable(centroidCoordinates)
                );
                centroidCoordinates.clear();
            }
        }
    }


    //The input of the mapper is an offset as the key, a point represented in a line and the context
    //The context contains the dimension of R^d and a list containing the actual centroids as strings
    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
    {

        //The minimum distance is initialized with the max value that a double variable can assume and the index is initialized with -1
        //In this way it is guaranteed that at least one centroid is found as centroid with the minimum distance
        double minDistance = Double.MAX_VALUE;
        int index = -1;

        //Parse the string to get the coordinates of the point
        String[] splitValue = value.toString().split(",");

        //parse string as point coordinates
        for(int i = 0; i<splitValue.length; ++i){
            String s = splitValue[i];
            elements.set(
                    i,
                    Double.parseDouble(s)
                    );
        }
        //initiate thisPoint using coordinates from elements
        thisPoint.setElements(elements);

        //Create an accumulator that has only the read point
        reducerValue.init();
        reducerValue.addPoint(thisPoint);

        //Initialize the distance to zero and find the index corresponding to centroid with the minimum distance from the point
        double distance = 0.0;

        for(int i = 0; i < centroids.size(); i++){
            distance = reducerValue.getSummedPoint().vectorNorm(centroids.get(i));
            if(distance <  minDistance){
                minDistance = distance;
                index = i;
            }
        }

        //set sum of squared error from the nearest centroid
        reducerValue.setSse(minDistance);
        //set index of nearest centroid
        outputKey.set(index);

        //Write the index corresponding to centroid with the minimum distance from the point and the read point (as an accumulator)
        context.write(outputKey, reducerValue);
    }

}