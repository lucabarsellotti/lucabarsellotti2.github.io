import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PointWritable implements WritableComparable<PointWritable>
{
    int d; //dimension -> R^d
    ArrayList<Double> elements; //coordinates in R^d


    public PointWritable(){
        d = 0;
        elements = new ArrayList<>();
    }

    public PointWritable(int d, ArrayList<Double> elements) {
        this.d = d;
        this.elements = elements;
    }

    //Generates and empty point, initialized with all zeros
    public PointWritable(int dimension){
        elements = new ArrayList<Double>();
        for(int i = 0; i < dimension; i++){
            elements.add(0.0);
        }
        this.d = dimension;
    }

    //Generates a point with a list of specified coordinates
    public PointWritable(List<Double> elements){
        this.elements = new ArrayList<Double>();
        this.elements.addAll(elements);
        this.d = elements.size();

    }

    //Generates a point with a list of specified coordinates contained in a string
    // s format: "x1,x2,x3,...,xn"
    public PointWritable(String s) {
        String[] coordinates = s.split(",");
        ArrayList<Double> res = new ArrayList<>();
        this.d = coordinates.length;
        for(String coord: coordinates) {
            res.add(Double.parseDouble(coord));
        }
        setElements(res);
    }

    //Computes the squared Euclidean norm between two points
    public Double vectorNorm(PointWritable a){
        double norm = 0.0;
        for(int i = 0; i < a.size(); i++){
            norm += Math.pow((this.get(i) - a.get(i)),2);
        }
        return norm;
    }

    public Double get(int i){
        return this.elements.get(i);
    }

    public int size(){
        return this.d;
    }

    public int getD() {
        return d;
    }

    public void setD(int d) {
        elements.clear();
        for(int i = 0; i < d; i++){
            elements.add(0.0);
        }
        this.d = d;
    }

    public ArrayList<Double> getElements() {
        return elements;
    }

    public void setElements(ArrayList<Double> elements) {
        for(int i = 0; i<this.elements.size(); ++i) {
            this.elements.set(i, elements.get(i));
        }
    }

    /*Writes the point in the format
        d
        coordinate_1
        ...
        coordinate_d
     */
    public void write(DataOutput out) throws IOException {
        //writing d, d attributes
        out.writeInt(d);
        for(int i=0;i<d;i++){
            out.writeDouble(this.elements.get(i));
        }
    }

    /*Reads a point passed in the format
        d
        coordinate_1
        ...
        coordinate_d
     */
    public void readFields(DataInput in) throws IOException {
        this.setD(in.readInt());
        ArrayList<Double> buffer = new ArrayList<Double>();
        for(int i=0;i<d;i++){
            buffer.add(in.readDouble());
        }
        this.setElements(buffer);
    }

    //Returns a string containing the list of coordinates in the format "x_1,...,x_d"
    @Override
    public String toString() {
        StringBuilder res = new StringBuilder();
        for(int i = 0; i<elements.size(); ++i) {
            res.append(elements.get(i).toString());
            if(i < elements.size() - 1)
                res.append(",");
        }
        return res.toString();
    }


    public int compareTo(PointWritable that){
        return 0;
    }


}