import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

//reservoir sampling mapper: emit a candidate centroid
//reservoir sampling reducer: receive a list of candidate centroid and for every key choose the last one based on the offset
public class CandidateCentroidWritable implements WritableComparable<CandidateCentroidWritable> {
    //represent a point in CSV format
    private String row;
    private long offset;

    public int compareTo(CandidateCentroidWritable o) {
        long thisValue = this.offset;
        long thatValue = o.offset;
        return(Long.compare(thisValue, thatValue));
    }

    public String getRow() {
        return row;
    }

    public void setRow(String row) {
        this.row = row;
    }

    public long getOffset() {
        return offset;
    }

    public void setOffset(long offset) {
        this.offset = offset;
    }

    @Override
    public String toString() { return row; }

    public void write(DataOutput out) throws IOException {
        out.writeLong(offset);
        out.writeChars(row+'\n');
    }

    public void readFields(DataInput in) throws IOException {
        this.offset = in.readLong();
        this.row = in.readLine();
    }
}
