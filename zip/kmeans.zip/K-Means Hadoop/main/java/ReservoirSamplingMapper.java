import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;

public class ReservoirSamplingMapper extends Mapper<LongWritable, Text, IntWritable, CandidateCentroidWritable> {
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        int k = context.getConfiguration().getInt("k", 3);
        long offset = key.get();

        long randomValue;

        //since the k elements must be emitted we set randomValue = offset to be sure that the second if will be executed
        if(offset < k)
            randomValue = offset;
        //while in this case, a random value between 0 and offset must be extracted
        else
            randomValue = ThreadLocalRandom.current().nextLong(offset);

        //if random value is lower than k than we emit that point
        //usually during reservoir sampling the point should replace the point with the index equal to the random extracted value,
        //this action will be performed by the reducer
        if (randomValue < k){
            CandidateCentroidWritable ccw = new CandidateCentroidWritable();
            ccw.setRow(value.toString());
            ccw.setOffset(key.get());
            int outputKey = (int) randomValue;
            context.write(new IntWritable(outputKey), ccw);
        }
    }
}
