import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class KMeansReducer extends Reducer<IntWritable, AccumulatorWritable,IntWritable, AccumulatorWritable> {

    private final AccumulatorWritable totalAccumulator = new AccumulatorWritable();

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);

        Configuration conf = context.getConfiguration();
        int dimension = conf.getInt("dimension",1);

        totalAccumulator.setD(dimension);
    }

    //The input of the reducer/combiner is a cluster index with a list of points, passed through AccumulatorWritable, assigned to that index
    @Override
    public void reduce(IntWritable key, Iterable<AccumulatorWritable> values, Context context)
            throws IOException, InterruptedException {

        //Create an accumulator object to sum points having the same cluster index
        totalAccumulator.init();
        //The "add" method called on the Accumulator increases also a variable containing the number of points summed and SSE
        for(AccumulatorWritable aw: values){
            totalAccumulator.add(aw);
        }

        //Write the cluster index, the sum and the number of points (represented by an Accumulator) in the context as result
        context.write(key, totalAccumulator);
    }

}
