import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;


public class ReservoirSamplingReducer extends Reducer<IntWritable, CandidateCentroidWritable, IntWritable, CandidateCentroidWritable> {

    private CandidateCentroidWritable result = null;

    @Override
    public void reduce(IntWritable key, Iterable<CandidateCentroidWritable> values, Context context)
            throws IOException, InterruptedException {

        //select last point, in terms of number of lines, emitted by the mapper for current key
        for(CandidateCentroidWritable candidate: values){
            if (result == null)
                result = candidate;
            //compare to return a value > 0 if the offset (the number of line) of candidate is higher than the offset of the result
            result = candidate.compareTo(result) > 0 ? candidate : result;
        }

        context.write(key, result);

    }
}
