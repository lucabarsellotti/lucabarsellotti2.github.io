//BARILS

/*map(
    LongWritable key, Text value,
    IntWritable key(indice del closest cluster), PointWritable p
    )

combiner(
    IntWritable key, IterablePointWritable p,
    IntWritable key(indice del cluster), AccumulatorWritable(somma punti+numero punti)
    )

reducer(
    IntWritable key, IterableAccumulatorWritable p,
    IntWritable key, PointWritable p(new centroid)
    )

Sampler

mapper(
    LongWritable offset, Text riga
    IntWritable(1-k), CandidateCentroidWritable(Text riga, LongWritable offset)
)

combiner(
    IntWritable(1-k), IterableCandidateCentroidWritable
    IntWritable(1-k), CandidateCentroidWritable
)

reducer(
    IntWritable(1-k), IterableCandidateCentroidWritable
    IntWritable(1-k), CandidateCentroidWritable
)
*/



