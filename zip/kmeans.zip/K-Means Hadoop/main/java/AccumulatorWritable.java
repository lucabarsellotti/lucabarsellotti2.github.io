import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//mapper: represent a single point
//combiner: sum of points assigned to the same centroid
//reducer: same as combiner
public class AccumulatorWritable implements WritableComparable<AccumulatorWritable>
{
    int numberOfPoints;
    PointWritable summedPoint;
    double sse;

    public void setSse(double sse) {
        this.sse = sse;
    }

    public AccumulatorWritable() {
        sse = 0;
        numberOfPoints = 0;
        summedPoint = new PointWritable();
    }

    //Generates an accumulator with a certain dimension and with the sum equal to zero in each coordinate
    //"dimension" is the dimension of each point
    public AccumulatorWritable(int dimension){
        sse = 0;
        summedPoint = new PointWritable(dimension);
        numberOfPoints = 0;
    }

    //Sums the point coordinate by coordinate and increases the total number of points in the accumulator by 1
    public void addPoint(PointWritable point){
        ArrayList<Double> elements = summedPoint.getElements();

        ArrayList<Double> pointToAdd = point.getElements();

        for(int i=0;i<summedPoint.getD();i++){
            Double t = elements.get(i);
            Double e = pointToAdd.get(i);
            Double sum = t+e;
            elements.set(i,sum);
        }
        this.summedPoint.setElements(elements);
        numberOfPoints++;
    }

    //Merges two accumulators together with the sum of the sums and the sum of the total numbers of points
    public void add(AccumulatorWritable that) {
        addPoint(that.getSummedPoint());
        this.sse += that.getSse();
        this.numberOfPoints += (that.getNumberOfPoints() - 1);
        System.out.println(this.numberOfPoints);
    }

    public double getSse() {
        return this.sse;
    }


    /*Writes the accumulator in the format
        total_number_of_points
        sse = sum of squared errors
        d
        sum_on_coordinate_1
        ...
        sum_on_coordinate_d
     */
    public void write(DataOutput out) throws IOException {
        out.writeInt(this.numberOfPoints);
        out.writeDouble(this.sse);
        summedPoint.write(out);
    }

    public int compareTo(AccumulatorWritable that){
        return 0;
    }

    /*Reads an accumulator from the format
        total_number_of_points
        sse = sum of squared errors
        d
        sum_on_coordinate_1
        ...
        sum_on_coordinate_d
     */
    public void readFields(DataInput in) throws IOException {
        this.numberOfPoints = in.readInt();
        System.out.println("num of points readfields: " + this.numberOfPoints);
        this.sse = in.readDouble();
        System.out.println("sse readfields: " + this.sse);
        summedPoint.readFields(in);
    }

    //Returns a point that has each coordinate given by the average of the summed points in the accumulator
    //Each average is given by sum_on_coordinate_i/total_number_of_points
    public PointWritable getAverageCentroid() {
        PointWritable res = new PointWritable(summedPoint.getD());
        ArrayList<Double> elements = new ArrayList<>();
        for(Double elem: summedPoint.getElements()) {
            elements.add(elem/numberOfPoints);
        }
        res.setElements(elements);
        return res;
    }

    //Returns a string containing the list of the coordinates of the sum in the format "x_1,...,x_d"
    @Override
    public String toString() {
        return getAverageCentroid().toString() +
                '/' + this.sse + '/' + this.numberOfPoints;
    }

    public int getNumberOfPoints(){
        return numberOfPoints;
    }

    public PointWritable getSummedPoint(){
        return summedPoint;
    }

    public void setNumberOfPoints(int numberOfPoints) {
        this.numberOfPoints = numberOfPoints;
    }

    public void init() {
        ArrayList<Double> elems = this.getSummedPoint().getElements();
        for(int i = 0; i < elems.size(); ++i) {
            elems.set(i, 0.0);
        }
        this.sse = 0.0;
        this.numberOfPoints = 0;
    }

    public void setD(int d) {
        this.summedPoint.setD(d);
    }
}
