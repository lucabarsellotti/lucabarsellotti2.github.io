import sys
import numpy as np
import random
import time
from pyspark import SparkContext


#   line: string containing the attributes of a point, comma separated values
#   return: numpy array representing the point
def read_point(line):
    return np.fromstring(line, dtype=np.float32, sep=',')


#   point: numpy array representing a point
#   centroids: broadcast variable that contains k numpy array, each one representing a centroid
#   return: index of the closest centroid to the point
def nearest_centroid(point, centroids):
    distances = []
    for centroid in centroids.value:
        distances.append(evaluate_distance(point, centroid))
    return np.argmin(distances)


#   point: numpy array representing a point
#   centroids: broadcast variable that contains k numpy array, each one representing a centroid
#   return: distance from the closest centroid
def nearest_centroid_distance(point, centroids):
    distances = []
    for centroid in centroids.value:
        distances.append(evaluate_distance(point, centroid))
    index = np.argmin(distances)
    return distances[index]


#   points: list of (points,distance)
#   return: average of the points, coordinate by coordinate
def generate_centroid(points):
    tmp = list()
    for point in points:
        tmp.append(point[0])
    return np.average(tmp, axis=0)


#   evaluate the distance between point1 and point2
def evaluate_distance(point1, point2):
    tmp = 0
    for j in range(0, dimension):
        tmp += pow(point1[j] - point2[j], 2)
    return tmp


#   distances: list containing tuples in this format (point, distance)
#   return: sum of all distances in the list

def compute_objective(distances):
    tmp = list()
    for distance in distances:
        tmp.append(distance[1])
    return sum(tmp)


if __name__ == "__main__":
    """
        Usage: kmeans <dimension> <k> <maxNumberOfIterations> <inputFile> <outputDirectory> <dimension>
    """

    args = sys.argv
    if len(args) != 7:
        print("Usage: kmeans < dimension > < k > < maxNumberOfIterations > < inputFile > < outputDirectory > < threshold >")
        exit()
    #   k: number of cluster
    #   seed: random seed for extracting each time new initial centroid
    #   maxNumberOfIteration: maximum number of iteration for the algorithm
    #   threshold: threshold to use as a stopping criteria
    dimension = int(args[1])
    k = int(args[2])
    maxNumberOfIteration = int(args[3])
    inputFile = args[4]
    outputDirectory = args[5]
    threshold = float(args[6])

    #   seed used to extract random centroids
    seed = random.randint(0, 10000)

    currentIteration = 0

    #   starting the timer to evaluate performance
    start_time = time.time()

    master = "yarn"
    #   SparkContext object, representing the connection to the cluster
    #   master = "yarn" for telling the application to run on the cluster and not in local
    sc = SparkContext(appName="KMeans", master=master)
    sc.setLogLevel("ERROR")

    #   Read lines from the text file and creating the RDD: each line contains a point object
    #   The rdd just created is then filtered(just line containing something) and then
    #   each element is transformed into numpy vector (map(read_point)).
    #   On the final rdd is then called cache() for better performance
    points = sc.textFile(inputFile).filter(lambda line: len(line) > 0).map(read_point).cache()
    numberOfPoints = points.count()

    #   Sampling k points from the RDD: our initial centroids. TakeSample is an action.
    centroids = points.takeSample(False, k, seed)
    print("centroids: " + str(centroids))

    #   converting the sampled centroids into a numpy array of array
    old_centroids = np.zeros(shape=(k, dimension))
    for i in range(0, k):
        old_centroids[i] = centroids[i]

    #   broadcasting old_centroids for performance
    old_centroids = sc.broadcast(old_centroids)

    print("old centroids before loop: " + np.array_str(old_centroids.value))
    print("old centroids size: " + str(len(old_centroids.value)))

    while currentIteration < maxNumberOfIteration:

        #   This is the mapper: for each point, we emit the index of the closest centroid and the point itself
        emitted_points = points.map(lambda point: (
            nearest_centroid(point, old_centroids), [point, nearest_centroid_distance(point, old_centroids)]))

        #   Group points by key: for each cluster (represented by the key)
        #   we emit the index and the list of points associated to that cluster
        #   we use groupByKey instead of reduceByKey because we need to emit a tuple of another type
        grouped_points = emitted_points.groupByKey()

        #   This is the reducer: for each tuple (composed by the cluster index and the list of points)
        #   we emit the the cluster index and the centroid, given by the average of the points
        reduced_points = grouped_points.map(lambda x: (x[0], (generate_centroid(list(x[1])), compute_objective(list(x[1]))))).sortByKey()

        #   final action to trigger computation
        collected_points = reduced_points.collect()

        #   evaluate current objective function
        #   we have as input to the map <index closest centroid, list of (point assigned to the centroid, distance)>
        #   compute_objective returns the sum of the distance for each centroid to its points
        #   distances = grouped_points.map(lambda x: (x[0],compute_objective(list(x[1]) ))).sortByKey().collect()

        #   print("distances: " + str(distances))

        #   sum of each total distance for each centroid to have the final sum
        current_distance = 0
        for iterator in collected_points:
            #   iterator= (index,(centroid, sse))
            current_distance += iterator[1][1]
        current_distance /= numberOfPoints

        #   at first iteration we set the old_distance to current_distance+threshold+1 so in this way we are sure that
        #   at least one iteration is done
        if currentIteration == 0:
            old_distance = current_distance + threshold + 1

        print("old_distance: " + str(old_distance))
        print("cur_distance: " + str(current_distance))
        print("difference: " + str(old_distance - current_distance))
        #   if the old_distance and current_distance differs less than the threshold then we can stop,
        #   since we are "near" to the minimum of the objective function

        if old_distance - current_distance < threshold:
            print("last iteration: " + str(currentIteration))
            break

        i = 0
        #   converting collected points into a numpy array of array
        new_centroids = np.zeros(shape=(k, dimension))
        for iterator in collected_points:
            new_centroids[i] = np.asarray(iterator[1][0])
            i += 1

        #   distance between old and new centroids for alternative stopping condition (NOT USED)
        #   centroidDistance = 0
        #   for (point1, point2) in zip(new_centroids, old_centroids.value):
        #       centroidDistance += evaluate_distance(point1, point2)

        #   print("distances between centroids: " + str(centroidDistance))
        print("new centroids: " + np.array_str(new_centroids))
        print("old centroids: " + np.array_str(old_centroids.value))

        #   updating old_centroids, so in the next iteration of the algorithm we will use the new ones

        old_centroids = new_centroids
        old_centroids = sc.broadcast(old_centroids)
        old_distance = current_distance
        #   increasing the number of iterations, to use as stopping condition
        currentIteration += 1

    print("--- elapsed time in seconds ---" + str(time.time() - start_time))

    print("final centroids are: " + str(old_centroids))
    #   action to save the final rdd into a file
    reduced_points.saveAsTextFile(outputDirectory)
